#include "robot.h"
#include "robot_types.h"
#include "robot_error.h"
#include <stdio.h>
#include <string.h>
#include <cstdlib>
#include <iostream>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <xmlrpc-c/base.h>
#include <xmlrpc-c/client.h>


//SDK版本号
#define SDK_VERSION_MAJOR         "2"
#define SDK_VERSION_MINOR         "0"
#define SDK_VERSION_RELEASE       "0"
#define SDK_VERSION_RELEASE_NUM   "0"

#define SDK_VERSION   "SDK V" SDK_VERSION_MAJOR "." SDK_VERSION_MINOR
#define SDK_RELEASE   SDK_VERSION "." SDK_VERSION_RELEASE "." SDK_VERSION_RELEASE_NUM

//FAIR ROBOT版本号
#define FAIR_VERSION_MAJOR      "3"
#define FAIR_VERSION_MINOR      "6"


#define  NAME  "Xmlrpc-c Test Client"
#define  VERSION  "1.0"

#define ROBOT_REALTIME_PORT  20004
#define ROBOT_CMD_PORT 8080
#define BUFFER_SIZE 1024*4
#define MAX_CHECK_CNT_COM  25

using  namespace std;

static int sock_cli_cmd;
static int sock_cli_state;
static uint8_t robot_realstate_exit = 0;
static uint8_t robot_instcmd_send_exit = 0;
static uint8_t robot_instcmd_recv_exit = 0;
static uint8_t robot_task_exit = 0;
static bool is_sendcmd = false;
static char g_sendbuf[BUFFER_SIZE] = {0};
static char g_recvbuf[BUFFER_SIZE] = {0};
static int  g_sock_com_err = ERR_SUCCESS;

char robot_ip[64];
ROBOT_STATE_PKG robot_state_pkg;

// char serverUrl[64];

static int dieIfFaultOccurred(xmlrpc_env * const envP)
{
	if(envP->fault_occurred)
	{
		fprintf(stderr,"ERROR: %s  (%d)\n", envP->fault_string, envP->fault_code);
        if(envP->fault_code == -504)
        {
            printf("fault code = %d\n", envP->fault_code);
            return ERR_XMLRPC_COM_FAILED;
        }
        else
        {
            return ERR_XMLRPC_CMD_FAILED;
        }
		
	}
    else
    {
        return ERR_SUCCESS;
    }
}

/**
 * @brief  机器人接口类构造函数
 */
FRRobot::FRRobot(void)
{
	char url[64] = "http://192.168.58.2:20003/RPC2";
	memset(serverUrl, 0, 64);
	strncpy(serverUrl, url, strlen(url));

    char default_ip[64] = "192.168.58.2";
    memset(robot_ip, 0, 64);
    strncpy(robot_ip, default_ip, strlen(default_ip));

    memset(&robot_state_pkg, 0, sizeof(ROBOT_STATE_PKG));

    sock_cli_state = -1;
    sock_cli_cmd = -1;
    robot_instcmd_recv_exit = 0;
    robot_instcmd_send_exit = 0;
    robot_realstate_exit = 0;
    robot_task_exit = 0;
    g_sock_com_err = ERR_SUCCESS;
}

/**
 * @brief 机器人状态反馈处理线程 
 */
void* FRRobot::RobotStateRoutineThread(void *arg)
{
    uint8_t recvbuf[BUFFER_SIZE] = {0};
    uint8_t tmp_recvbuf[BUFFER_SIZE] = {0};
    uint8_t state_pkg[BUFFER_SIZE] = {0};
    uint8_t *ptr_state = (uint8_t*)&robot_state_pkg;
    int i;
    uint8_t find_head_flag = 0;
    uint16_t index = 0;
    uint16_t len = 0;
    uint16_t tmp_len = 0;
    int recvbyte = 0;

    pthread_detach(pthread_self());       

    /* 建立通讯 */
    sock_cli_state = socket(AF_INET,SOCK_STREAM, 0);
 
    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(ROBOT_REALTIME_PORT);  ///服务器端口
    servaddr.sin_addr.s_addr = inet_addr(robot_ip);  ///服务器ip
 
    ///连接服务器，成功返回0，错误返回-1
    if (connect(sock_cli_state, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
    {
        perror("connect");
        printf("state connect:%s\n", strerror(errno));
        g_sock_com_err = ERR_SOCKET_COM_FAILED;
        return NULL;
    }

    // int keepAlive = 1; //开启keepAlive属性
    // int keepIdle = 1; //如该连接在10s内没有任何数据往来，则进行探测
    // int keepInterval = 0.1; //探测时发包时间间隔为5s
    // int keepCount = 3; //探测尝试次数，如果第1次探测包就收到响应了，则后2次的不再发

    // setsockopt(sock_cli_state, SOL_SOCKET, SO_KEEPALIVE, (void*)&keepAlive, sizeof(keepAlive));
    // setsockopt(sock_cli_state, SOL_TCP, TCP_KEEPIDLE, (void*)&keepIdle, sizeof(keepIdle));
    // setsockopt(sock_cli_state, SOL_TCP, TCP_KEEPINTVL, (void*)&keepInterval, sizeof(keepInterval));
    // setsockopt(sock_cli_state, SOL_TCP, TCP_KEEPCNT, (void*)&keepCount, sizeof(keepCount));

    while(!robot_realstate_exit)
    {
        bzero(recvbuf, BUFFER_SIZE);

        recvbyte = recv(sock_cli_state, recvbuf, BUFFER_SIZE, 0);
        //printf("recvbyte = %d\n", recvbyte);
        if(recvbyte < 0)
        {
            printf("state recv:%s\n", strerror(errno));
	    shutdown(sock_cli_state, 2);
            close(sock_cli_state);
            sock_cli_state = -1;
            g_sock_com_err = ERR_SOCKET_COM_FAILED;
            return NULL;
        }
        else
        {
            /* 判断是否有上一次数据残留 */
            if(tmp_len > 0)
            {
                if((tmp_len + recvbyte) <= BUFFER_SIZE)
                {
                    memcpy(tmp_recvbuf+tmp_len, recvbuf, recvbyte);
                    bzero(recvbuf, BUFFER_SIZE);
                    memcpy(recvbuf, tmp_recvbuf, tmp_len+recvbyte);

                    tmp_len = 0;
                    bzero(tmp_recvbuf, BUFFER_SIZE);
                }
                else
                {
                    /* 清除上一次数据残留 */
                    tmp_len = 0;
                    bzero(tmp_recvbuf, BUFFER_SIZE);
                }
            }
            else
            {
                tmp_len = 0;
                bzero(tmp_recvbuf, BUFFER_SIZE);
            }

            for(i = 0; i < recvbyte; i++)
            {

                /* 找帧头1 */
                if(recvbuf[i] == 0x5A && find_head_flag == 0)
                {
                    /* 判断帧头+CNT+LEN数据长度能否满足解析要求 */
                    if((i+4) < recvbyte)
                    {
                        /* 找帧头2 */
                        if(recvbuf[i+1] == 0x5A)
                        {
                            find_head_flag = 1;
                            memcpy(state_pkg, recvbuf+i, 1);
                            index++;
                            len = len | recvbuf[i+4];
                            len = len << 8;
                            len = len | recvbuf[i+3];
                            // printf("len = %u\n", len);                           
                        }
                        else
                        {
                            continue;
                        }
                    }
                    else
                    {
                        /* 剩余数据存入临时变量 */
                        memcpy(tmp_recvbuf, recvbuf+i, recvbyte-i);
                        tmp_len = recvbyte-i;
                        // printf("start tmp_len = %u, i=%d, recv=%d\n", tmp_len, i, recvbyte);    
                        break;
                    }
                }
                else if(find_head_flag == 1 && index < len + 5)
                {
                    memcpy(state_pkg+index, recvbuf+i, 1);
                    index++;
                }
                else if(find_head_flag == 1 && index >= len + 5)
                {
                    if((i+1) < recvbyte)
                    {
                        int j;
                        uint16_t checksum = 0;
                        uint16_t checkdata = 0;

                        checkdata = checkdata | recvbuf[i+1];
                        checkdata = checkdata << 8;
                        checkdata = checkdata | recvbuf[i];

                        for(j = 0; j < index; j++)
                        {
                            checksum  += state_pkg[j];
                        }

                        if(checksum == checkdata)
                        {
                            //printf("check success\n");
                            memcpy(ptr_state, state_pkg, sizeof(ROBOT_STATE_PKG));
                            bzero(state_pkg, BUFFER_SIZE);
                            find_head_flag = 0;
                            index = 0;
                            len = 0;
                            i++;
                            // printf("cnt11=%u, len=%d\n", robot_state_pkg.frame_cnt, robot_state_pkg.data_len);
                        }
                        else
                        {
                            find_head_flag = 0;
                            index = 0;
                            len = 0;
                            i++;
                        }
                    }
                    else
                    {
                        /* 剩余数据存入临时变量 */
                        memcpy(tmp_recvbuf, recvbuf+i, recvbyte-i);
                        tmp_len = recvbyte-i;
                        // printf("end tmp_len = %u, i=%d, recv=%d\n", tmp_len, i, recvbyte);    
                        break;
                    }
                }
                else
                {
                    continue;
                }
            }
        }

    }

    if(sock_cli_state > 0)
    {
        printf("state thread exit\n");
        shutdown(sock_cli_state, 2);
        close(sock_cli_state);
        sock_cli_state = -1;
        g_sock_com_err = ERR_SOCKET_COM_FAILED;
    }

    return NULL;
}

/**
 * @brief 即时指令发送处理线程 
 */
void* FRRobot::RobotInstCmdSendRoutineThread(void *arg)
{
    int sendbyte = 0;

    pthread_detach(pthread_self());    

    /* 建立通讯 */
    sock_cli_cmd = socket(AF_INET,SOCK_STREAM, 0);
 
    struct sockaddr_in servaddr;
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(ROBOT_CMD_PORT);  ///服务器端口
    servaddr.sin_addr.s_addr = inet_addr(robot_ip);  ///服务器ip
 
    ///连接服务器，成功返回0，错误返回-1
    if (connect(sock_cli_cmd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0)
    {
        perror("connect failed");
        printf("cmd connect:%s\n", strerror(errno));
        g_sock_com_err = ERR_SOCKET_COM_FAILED;        
        return NULL;
    }

    printf("cmd connect success\n");

    while(!robot_instcmd_send_exit)
    {
        if(is_sendcmd && strlen(g_sendbuf) > 0)
        {
            sendbyte = send(sock_cli_cmd, g_sendbuf, strlen(g_sendbuf), 0);
            printf("cmd send:%s\n", g_sendbuf);
            if(sendbyte < 0)
            {
                printf("cmd send:%s\n", strerror(errno));
                shutdown(sock_cli_cmd, 2);
                close(sock_cli_cmd);
                sock_cli_cmd = -1;
                g_sock_com_err = ERR_SOCKET_COM_FAILED;
                printf("cmd send error");           
                return NULL;
            } 
            is_sendcmd = false;
        }
        else
        {
            usleep(1000);
        }
    }

    if(sock_cli_cmd > 0)
    {
        printf("cmdsend thread exit\n");
        shutdown(sock_cli_cmd, 2);
        close(sock_cli_cmd);
        sock_cli_cmd = -1;
        g_sock_com_err = ERR_SOCKET_COM_FAILED;    
    }

    return NULL;
}

/**
 * @brief 即时指令接收处理线程 
 */
void* FRRobot::RobotInstCmdRecvRoutineThread(void *arg)
{
    int recvbyte;

    pthread_detach(pthread_self());   

    while(!robot_instcmd_recv_exit)
    {
        bzero(g_recvbuf, BUFFER_SIZE);
        recvbyte = recv(sock_cli_cmd, g_recvbuf, BUFFER_SIZE, 0);
        if(recvbyte < 0)
        {
            printf("cmd recv:%s\n", strerror(errno));
            shutdown(sock_cli_cmd, 2);
            close(sock_cli_cmd);
            sock_cli_cmd = -1;
            g_sock_com_err = ERR_SOCKET_COM_FAILED;
            return NULL;
        }
    }

    if(sock_cli_cmd > 0)
    {
        printf("cmdrecv thread exit\n");
        shutdown(sock_cli_cmd, 2);
        close(sock_cli_cmd);
        sock_cli_cmd = -1;
        g_sock_com_err = ERR_SOCKET_COM_FAILED;
    }

    return NULL;
}

/**
 * @brief 任务处理线程 
 */
void* FRRobot::RobotTaskRoutineThread(void *arg)
{
    static uint8_t s_last_frame_cnt;
    static uint8_t s_isFirst = 0;
    static uint8_t s_check_cnt = 0;
    static uint32_t s_last_time = 0;

    printf("task routine\n");

    pthread_detach(pthread_self());   

    while(!robot_task_exit)
    {
        if(g_sock_com_err == ERR_SUCCESS && sock_cli_state > 0)
        {
            struct timeval tv;
            gettimeofday(&tv, NULL);     //打时间戳
            uint32_t curtime = tv.tv_sec*1000000 + tv.tv_usec;
            
            if(!s_isFirst)
            {
                s_last_frame_cnt = robot_state_pkg.frame_cnt;
                s_last_time = curtime;
                s_isFirst = 1;
            }
            else
            {
                //printf("dt time = %u, cnt = %u, lastcnt = %u\n", curtime-s_last_time, robot_state_pkg.frame_cnt, s_last_frame_cnt);
                if(((robot_state_pkg.frame_cnt - s_last_frame_cnt) == 0) && ((curtime - s_last_time) < 2*8000))
                {

                    s_check_cnt++;
                    //printf("check cnt = %u\n", s_check_cnt);
                    if(s_check_cnt >= MAX_CHECK_CNT_COM)
                    {
                        g_sock_com_err = ERR_SOCKET_COM_FAILED;
                        s_check_cnt = 0;
                    }
                }
                else
                {
                    s_check_cnt = 0;
                }

                s_last_frame_cnt = robot_state_pkg.frame_cnt;
                s_last_time = curtime;
            }
        }

        usleep(8000);
    }

    s_isFirst = 0;

    return NULL;
}

/** 
 * @brief  与机器人控制器建立通信
 * @param  [in] ip  控制器IP地址，出场默认为192.168.58.2
 * @return 错误码
 */
errno_t  FRRobot::RPC(const char *ip)
{
    sock_cli_state = -1;
    sock_cli_cmd = -1;
    robot_instcmd_recv_exit = 0;
    robot_instcmd_send_exit = 0;
    robot_realstate_exit = 0;
    robot_task_exit = 0;
    g_sock_com_err = ERR_SUCCESS;

	memset(serverUrl, 0, 64);
	sprintf(serverUrl, "http://%s:20003/RPC2", ip);
	printf("serverUrl:%s\n", serverUrl);

    memset(robot_ip, 0, 64);
    strncpy(robot_ip, ip, strlen(ip));

    pthread_t robot_state_id, robot_sendcmd_id, robot_recvcmd_id, robot_task_id;

    if(pthread_create(&robot_state_id, NULL, RobotStateRoutineThread, NULL))
    {
        printf("robot state create thread failed\n");
        g_sock_com_err = ERR_SOCKET_COM_FAILED;
        return ERR_SOCKET_COM_FAILED;
    }

    if(pthread_create(&robot_sendcmd_id, NULL, RobotInstCmdSendRoutineThread, NULL))
    {
        printf("robot sendcmd create thread failed\n");
        g_sock_com_err = ERR_SOCKET_COM_FAILED;
        return ERR_SOCKET_COM_FAILED;
    }

    sleep(0.5);

    if(pthread_create(&robot_recvcmd_id, NULL, RobotInstCmdRecvRoutineThread, NULL))
    {
        printf("robot recvcmd create thread failed\n");
        g_sock_com_err = ERR_SOCKET_COM_FAILED;
        return ERR_SOCKET_COM_FAILED;
    }

    sleep(0.5);

    if(pthread_create(&robot_task_id, NULL, RobotTaskRoutineThread, NULL))
    {
        printf("robot task create thread failed\n");
        g_sock_com_err = ERR_SOCKET_COM_FAILED;
        return ERR_SOCKET_COM_FAILED;
    }

    printf("create success\n");

	return 0;
}


/**
 * @brief  与机器人控制器关闭通讯
 * @return 错误码
 */
errno_t  FRRobot::CloseRPC()
{
    if(sock_cli_cmd > 0)
    {
	    shutdown(sock_cli_cmd, 2);
        close(sock_cli_cmd);
        sock_cli_cmd = -1;
    }

    if(sock_cli_state > 0)
    {
        shutdown(sock_cli_state, 2);
        close(sock_cli_state);
        sock_cli_state = -1;
    }

    sleep(0.5);

    robot_instcmd_send_exit = 1;
    robot_instcmd_recv_exit = 1;
    robot_realstate_exit = 1;
    robot_task_exit = 1;

    g_sock_com_err = ERR_SUCCESS;

    //sleep(5);

    return 0;
}

/**
 * @brief  查询SDK版本号
 * @param  [out] version   SDK版本号
 * @return  错误码
 */	 
errno_t  FRRobot::GetSDKVersion(char *version)
{
    // const char * const methodName = "GetSDKVersion";
    
    // xmlrpc_env env;
    // xmlrpc_value *resultP;
    // xmlrpc_int32  errcode;
    // const char *str;
    
    // xmlrpc_env_init(&env);
    // xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	// dieIfFaultOccurred(&env);
    
    // resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	// dieIfFaultOccurred(&env);
	
	// int size = xmlrpc_array_size(&env, resultP);
	// dieIfFaultOccurred(&env);
	
	// xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
	// dieIfFaultOccurred(&env);    
    // xmlrpc_read_int(&env, strctP0, &errcode);
	// dieIfFaultOccurred(&env);
	
	// xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
	// dieIfFaultOccurred(&env);    
    // xmlrpc_read_string(&env, strctP1, &str);
	// dieIfFaultOccurred(&env);	
	// strncpy(version, str, strlen(str));
    
    // xmlrpc_DECREF(resultP);
    // xmlrpc_env_clean(&env);
    // xmlrpc_client_cleanup();

    int errcode = 0;

    //char tmp_version[256] = SDK_RELEASE;

    strncpy(version, SDK_RELEASE, strlen(SDK_RELEASE));
    
    return errcode;		
}

/**
 * @brief  获取控制器IP
 * @param  [out] ip  控制器IP
 * @return  错误码
 */
errno_t  FRRobot::GetControllerIP(char *ip)
{
    const char * const methodName = "GetControllerIP";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    const char *str;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();      
        return errcode;  
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();      
        return errcode;          
    }
	
    int size = xmlrpc_array_size(&env, resultP);
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }    

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    errcode = dieIfFaultOccurred(&env);   

    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }    	
    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    errcode = dieIfFaultOccurred(&env);    
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }        
    xmlrpc_read_string(&env, strctP1, &str);
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }        
    strncpy(ip, str, strlen(str));	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();

    return errcode;			
}

/**
 * @brief  控制机器人进入或退出拖动示教模式
 * @param  [in] state 0-退出拖动示教模式，1-进入拖动示教模式
 * @return  错误码
 */
errno_t  FRRobot::DragTeachSwitch(uint8_t state)
{
    const char * const methodName = "DragTeachSwitch";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }        
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)state);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }      
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);        
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }   

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;		
}

/**
 * @brief  查询机器人是否处于拖动示教模式
 * @param  [out] state 0-非拖动示教模式，1-拖动示教模式
 * @return  错误码
 */
errno_t  FRRobot::IsInDragTeach(uint8_t *state)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        if(robot_state_pkg.robot_state == 4)
        {
            *state = 1;
        }
        else
        {
            *state = 0;
        }
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;		
}

/** 
 * @brief  控制机器人上使能或下使能，机器人上电后默认自动上使能
 * @param  [in] state  0-下使能，1-上使能
 * @return  错误码
 */
errno_t  FRRobot::RobotEnable(uint8_t state)
{
    const char * const methodName = "RobotEnable";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {   
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }   
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)state);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }   
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }   

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();

    if(robot_state_pkg.EmergencyStop == 1)
    {
        errcode = ERR_EXECUTION_FAILED;
    }
    
    return errcode;	
}

/**
 * @brief 控制机器人手自动模式切换
 * @param [in] mode 0-自动模式，1-手动模式
 * @return 错误码
 */
errno_t FRRobot::Mode(int mode)
{
    const char * const methodName = "Mode";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)mode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;
}

/**
 * @brief  jog点动
 * @param  [in]  ref 0-关节点动，2-基坐标系下点动，4-工具坐标系下点动，8-工件坐标系下点动
 * @param  [in]  nb 1-关节1(或x轴)，2-关节2(或y轴)，3-关节3(或z轴)，4-关节4(或绕x轴旋转)，5-关节5(或绕y轴旋转)，6-关节6(或绕z轴旋转)
 * @param  [in]  dir 0-负方向，1-正方向
 * @param  [in]  vel 速度百分比，[0~100]
 * @param  [in]  acc 加速度百分比， [0~100]
 * @param  [in]  max_dis 单次点动最大角度，单位[°]或距离，单位[mm]
 * @return  错误码
 */
errno_t  FRRobot::StartJOG(uint8_t ref, uint8_t nb, uint8_t dir, float vel, float acc, float max_dis)
{
    const char * const methodName = "StartJOG";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }      
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iiiddd)", (xmlrpc_int32)ref,(xmlrpc_int32)nb,(xmlrpc_int32)dir,(xmlrpc_double)vel,(xmlrpc_double)acc,(xmlrpc_double)max_dis);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	
}
	
/**
 * @brief  jog点动减速停止
 * @param  [in]  ref  1-关节点动停止，3-基坐标系下点动停止，5-工具坐标系下点动停止，9-工件坐标系下点动停止
 * @return  错误码
 */
errno_t  FRRobot::StopJOG(uint8_t ref)
{
    const char * const methodName = "StopJOG";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }     
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)ref);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }     
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;			
}
	
/**
 * @brief jog点动立即停止
 * @return  错误码
 */
errno_t  FRRobot::ImmStopJOG()
{
    const char * const methodName = "ImmStopJOG";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;		
}
	
/**
 * @brief  关节空间运动
 * @param  [in] joint_pos  目标关节位置,单位deg
 * @param  [in] desc_pos   目标笛卡尔位姿
 * @param  [in] tool  工具坐标号，范围[1~15]
 * @param  [in] user  工件坐标号，范围[1~15]
 * @param  [in] vel  速度百分比，范围[0~100]
 * @param  [in] acc  加速度百分比，范围[0~100],暂不开放
 * @param  [in] ovl  速度缩放因子，范围[0~100]
 * @param  [in] epos  扩展轴位置，单位mm
 * @param  [in] blendT [-1.0]-运动到位(阻塞)，[0~500.0]-平滑时间(非阻塞)，单位ms
 * @param  [in] offset_flag  0-不偏移，1-基坐标系/工件坐标系下偏移，2-工具坐标系下偏移
 * @param  [in] offset_pos  位姿偏移量
 * @return  错误码
 */
errno_t  FRRobot::MoveJ(JointPos *joint_pos, DescPose *desc_pos, int tool, int user, float vel, float acc, float ovl, ExaxisPos *epos, float blendT, uint8_t offset_flag, DescPose *offset_pos)
{
    const char * const methodName = "MoveJ";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP1,*arrayP2,*arrayP3,*arrayP4;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP1 = xmlrpc_array_new(&env);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    { 
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos->jPos[i]);
		errcode = dieIfFaultOccurred(&env);
        if(errcode)
        { 
            xmlrpc_env_clean(&env);
            xmlrpc_client_cleanup();   
            return errcode;          
        } 
		xmlrpc_array_append_item(&env, arrayP1, dividendP);
		errcode = dieIfFaultOccurred(&env);
        if(errcode)
        {
            xmlrpc_DECREF(dividendP);
            xmlrpc_env_clean(&env);
            xmlrpc_client_cleanup();   
            return errcode;          
        } 
		xmlrpc_DECREF(dividendP);
	}

	arrayP2 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

	arrayP3 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 4; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, epos->ePos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP3, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP4 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	xmlrpc_value *d5P1 = xmlrpc_double_new(&env, offset_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P1);
	xmlrpc_value *d5P2 = xmlrpc_double_new(&env, offset_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P2);
 	xmlrpc_value *d5P3 = xmlrpc_double_new(&env, offset_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P3);   
	xmlrpc_value *d5P4 = xmlrpc_double_new(&env, offset_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P4);
	xmlrpc_value *d5P5 = xmlrpc_double_new(&env, offset_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P5);
	xmlrpc_value *d5P6 = xmlrpc_double_new(&env, offset_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(AAiidddAdiA)",arrayP1,arrayP2,(xmlrpc_int32)tool,(xmlrpc_int32)user,(xmlrpc_double)vel,(xmlrpc_double)acc,(xmlrpc_double)ovl,arrayP3,(xmlrpc_double)blendT,(xmlrpc_int32)offset_flag,arrayP4);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;		
}

	
/**
 * @brief  笛卡尔空间直线运动
 * @param  [in] joint_pos  目标关节位置,单位deg
 * @param  [in] desc_pos   目标笛卡尔位姿
 * @param  [in] tool  工具坐标号，范围[1~15]
 * @param  [in] user  工件坐标号，范围[1~15]
 * @param  [in] vel  速度百分比，范围[0~100]
 * @param  [in] acc  加速度百分比，范围[0~100],暂不开放
 * @param  [in] ovl  速度缩放因子，范围[0~100]
 * @param  [in] blendR [-1.0]-运动到位(阻塞)，[0~1000.0]-平滑半径(非阻塞)，单位mm
 * @param  [in] epos  扩展轴位置，单位mm	
 * @param  [in] search  0-不焊丝寻位，1-焊丝寻位
 * @param  [in] offset_flag  0-不偏移，1-基坐标系/工件坐标系下偏移，2-工具坐标系下偏移
 * @param  [in] offset_pos  位姿偏移量
 * @return  错误码
*/	
errno_t  FRRobot::MoveL(JointPos *joint_pos, DescPose *desc_pos, int tool, int user, float vel, float acc, float ovl, float blendR, ExaxisPos *epos, uint8_t search, uint8_t offset_flag, DescPose *offset_pos)
{
    const char * const methodName = "MoveL";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP1,*arrayP2,*arrayP3,*arrayP4;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos->jPos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP1, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP2 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

	arrayP3 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 4; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, epos->ePos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP3, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP4 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	xmlrpc_value *d5P1 = xmlrpc_double_new(&env, offset_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P1);
	xmlrpc_value *d5P2 = xmlrpc_double_new(&env, offset_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P2);
 	xmlrpc_value *d5P3 = xmlrpc_double_new(&env, offset_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P3);   
	xmlrpc_value *d5P4 = xmlrpc_double_new(&env, offset_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P4);
	xmlrpc_value *d5P5 = xmlrpc_double_new(&env, offset_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P5);
	xmlrpc_value *d5P6 = xmlrpc_double_new(&env, offset_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(AAiiddddAiiA)",arrayP1,arrayP2,(xmlrpc_int32)tool,(xmlrpc_int32)user,(xmlrpc_double)vel,(xmlrpc_double)acc,(xmlrpc_double)ovl,(xmlrpc_double)blendR,arrayP3,(xmlrpc_int32)search,(xmlrpc_int32)offset_flag,arrayP4);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}

/**
 * @brief  笛卡尔空间圆弧运动
 * @param  [in] joint_pos_p  路径点关节位置,单位deg
 * @param  [in] desc_pos_p   路径点笛卡尔位姿
 * @param  [in] ptool  工具坐标号，范围[1~15]
 * @param  [in] puser  工件坐标号，范围[1~15]
 * @param  [in] pvel  速度百分比，范围[0~100]
 * @param  [in] pacc  加速度百分比，范围[0~100],暂不开放
 * @param  [in] epos_p  扩展轴位置，单位mm
 * @param  [in] poffset_flag  0-不偏移，1-基坐标系/工件坐标系下偏移，2-工具坐标系下偏移
 * @param  [in] offset_pos_p  位姿偏移量
 * @param  [in] joint_pos_t  目标点关节位置,单位deg
 * @param  [in] desc_pos_t   目标点笛卡尔位姿
 * @param  [in] ttool  工具坐标号，范围[1~15]
 * @param  [in] tuser  工件坐标号，范围[1~15]
 * @param  [in] tvel  速度百分比，范围[0~100]
 * @param  [in] tacc  加速度百分比，范围[0~100],暂不开放
 * @param  [in] epos_t  扩展轴位置，单位mm
 * @param  [in] toffset_flag  0-不偏移，1-基坐标系/工件坐标系下偏移，2-工具坐标系下偏移
 * @param  [in] offset_pos_t  位姿偏移量	 
 * @param  [in] ovl  速度缩放因子，范围[0~100]	 
 * @param  [in] blendR [-1.0]-运动到位(阻塞)，[0~1000.0]-平滑半径(非阻塞)，单位mm	 
 * @return  错误码
 */		
errno_t  FRRobot::MoveC(JointPos *joint_pos_p, DescPose *desc_pos_p, int ptool, int puser, float pvel, float pacc, ExaxisPos *epos_p, uint8_t poffset_flag, DescPose *offset_pos_p,JointPos *joint_pos_t, DescPose *desc_pos_t, int ttool, int tuser, float tvel, float tacc, ExaxisPos *epos_t, uint8_t toffset_flag, DescPose *offset_pos_t,float ovl, float blendR)
{
    const char * const methodName = "MoveC";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP1,*arrayP2,*arrayP3,*arrayP4,*arrayP5,*arrayP6,*arrayP7,*arrayP8,*arrayP9,*arrayP10;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos_p->jPos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP1, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP2 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pos_p->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pos_p->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pos_p->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pos_p->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pos_p->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pos_p->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);
	
	arrayP3 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);	
	xmlrpc_value *d3P1 = xmlrpc_double_new(&env, (double)ptool);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP3, d3P1);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d3P1);	
	xmlrpc_value *d3P2 = xmlrpc_double_new(&env, (double)puser);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP3, d3P2);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d3P2);
	xmlrpc_value *d3P3 = xmlrpc_double_new(&env, pvel);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP3, d3P3);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d3P3);
	xmlrpc_value *d3P4 = xmlrpc_double_new(&env, pacc);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP3, d3P4);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d3P4);	
	
	arrayP4 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 4; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, epos_p->ePos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP4, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP5 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	xmlrpc_value *d5P1 = xmlrpc_double_new(&env, offset_pos_p->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP5, d5P1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P1);
	xmlrpc_value *d5P2 = xmlrpc_double_new(&env, offset_pos_p->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP5, d5P2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P2);
 	xmlrpc_value *d5P3 = xmlrpc_double_new(&env, offset_pos_p->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP5, d5P3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P3);   
	xmlrpc_value *d5P4 = xmlrpc_double_new(&env, offset_pos_p->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP5, d5P4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P4);
	xmlrpc_value *d5P5 = xmlrpc_double_new(&env, offset_pos_p->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP5, d5P5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P5);
	xmlrpc_value *d5P6 = xmlrpc_double_new(&env, offset_pos_p->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP5, d5P6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P6);
	
	arrayP6 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos_t->jPos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP6, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP7 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *d7P1 = xmlrpc_double_new(&env, desc_pos_t->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP7, d7P1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d7P1);
	xmlrpc_value *d7P2 = xmlrpc_double_new(&env, desc_pos_t->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP7, d7P2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d7P2);
 	xmlrpc_value *d7P3 = xmlrpc_double_new(&env, desc_pos_t->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP7, d7P3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d7P3);   
	xmlrpc_value *d7P4 = xmlrpc_double_new(&env, desc_pos_t->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP7, d7P4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d7P4);
	xmlrpc_value *d7P5 = xmlrpc_double_new(&env, desc_pos_t->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP7, d7P5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d7P5);
	xmlrpc_value *d7P6 = xmlrpc_double_new(&env, desc_pos_t->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP7, d7P6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d7P6);
	
	arrayP8 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);	
	xmlrpc_value *d8P1 = xmlrpc_double_new(&env, (double)ttool);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP8, d8P1);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d8P1);	
	xmlrpc_value *d8P2 = xmlrpc_double_new(&env, (double)tuser);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP8, d8P2);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d8P2);
	xmlrpc_value *d8P3 = xmlrpc_double_new(&env, tvel);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP8, d8P3);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d8P3);
	xmlrpc_value *d8P4 = xmlrpc_double_new(&env, tacc);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP8, d8P4);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d8P4);	
	
	arrayP9 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 4; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, epos_t->ePos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP9, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP10 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	xmlrpc_value *d10P1 = xmlrpc_double_new(&env, offset_pos_t->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP10, d10P1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d10P1);
	xmlrpc_value *d10P2 = xmlrpc_double_new(&env, offset_pos_t->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP10, d10P2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d10P2);
 	xmlrpc_value *d10P3 = xmlrpc_double_new(&env, offset_pos_t->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP10, d10P3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d10P3);   
	xmlrpc_value *d10P4 = xmlrpc_double_new(&env, offset_pos_t->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP10, d10P4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d10P4);
	xmlrpc_value *d10P5 = xmlrpc_double_new(&env, offset_pos_t->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP10, d10P5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d10P5);
	xmlrpc_value *d10P6 = xmlrpc_double_new(&env, offset_pos_t->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP10, d10P6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d10P6);	

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(AAAAiAAAAAiAdd)",arrayP1,arrayP2,arrayP3,arrayP4,(xmlrpc_int32)poffset_flag,arrayP5,arrayP6,arrayP7,arrayP8,arrayP9,(xmlrpc_int32)toffset_flag,arrayP10,(xmlrpc_double)ovl,(xmlrpc_double)blendR);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	
}
	
/**
 * @brief  笛卡尔空间整圆运动
 * @param  [in] joint_pos_p  路径点1关节位置,单位deg
 * @param  [in] desc_pos_p   路径点1笛卡尔位姿
 * @param  [in] ptool  工具坐标号，范围[1~15]
 * @param  [in] puser  工件坐标号，范围[1~15]
 * @param  [in] pvel  速度百分比，范围[0~100]
 * @param  [in] pacc  加速度百分比，范围[0~100],暂不开放
 * @param  [in] epos_p  扩展轴位置，单位mm
 * @param  [in] joint_pos_t  路径点2关节位置,单位deg
 * @param  [in] desc_pos_t   路径点2笛卡尔位姿
 * @param  [in] ttool  工具坐标号，范围[1~15]
 * @param  [in] tuser  工件坐标号，范围[1~15]
 * @param  [in] tvel  速度百分比，范围[0~100]
 * @param  [in] tacc  加速度百分比，范围[0~100],暂不开放
 * @param  [in] epos_t  扩展轴位置，单位mm
 * @param  [in] ovl  速度缩放因子，范围[0~100]	
 * @param  [in] offset_flag  0-不偏移，1-基坐标系/工件坐标系下偏移，2-工具坐标系下偏移
 * @param  [in] offset_pos  位姿偏移量	 	 
 * @return  错误码
 */		
errno_t  FRRobot::Circle(JointPos *joint_pos_p, DescPose *desc_pos_p, int ptool, int puser, float pvel, float pacc, ExaxisPos *epos_p, JointPos *joint_pos_t, DescPose *desc_pos_t, int ttool, int tuser, float tvel, float tacc, ExaxisPos *epos_t, float ovl, uint8_t offset_flag, DescPose *offset_pos)
{
    const char * const methodName = "Circle";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP1,*arrayP2,*arrayP3,*arrayP4,*arrayP5,*arrayP6,*arrayP7,*arrayP8,*arrayP9;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos_p->jPos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP1, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP2 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pos_p->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pos_p->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pos_p->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pos_p->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pos_p->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pos_p->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);
	
	arrayP3 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);	
	xmlrpc_value *d3P1 = xmlrpc_double_new(&env, (double)ptool);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP3, d3P1);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d3P1);	
	xmlrpc_value *d3P2 = xmlrpc_double_new(&env, (double)puser);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP3, d3P2);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d3P2);
	xmlrpc_value *d3P3 = xmlrpc_double_new(&env, pvel);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP3, d3P3);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d3P3);
	xmlrpc_value *d3P4 = xmlrpc_double_new(&env, pacc);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP3, d3P4);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d3P4);	
	
	arrayP4 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 4; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, epos_p->ePos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP4, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}
	
	arrayP5 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos_t->jPos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP5, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP6 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *d6P1 = xmlrpc_double_new(&env, desc_pos_t->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP6, d6P1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d6P1);
	xmlrpc_value *d6P2 = xmlrpc_double_new(&env, desc_pos_t->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP6, d6P2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d6P2);
 	xmlrpc_value *d6P3 = xmlrpc_double_new(&env, desc_pos_t->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP6, d6P3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d6P3);   
	xmlrpc_value *d6P4 = xmlrpc_double_new(&env, desc_pos_t->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP6, d6P4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d6P4);
	xmlrpc_value *d6P5 = xmlrpc_double_new(&env, desc_pos_t->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP6, d6P5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d6P5);
	xmlrpc_value *d6P6 = xmlrpc_double_new(&env, desc_pos_t->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP6, d6P6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d6P6);
	
	arrayP7 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);	
	xmlrpc_value *d7P1 = xmlrpc_double_new(&env, (double)ttool);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP7, d7P1);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d7P1);	
	xmlrpc_value *d7P2 = xmlrpc_double_new(&env, (double)tuser);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP7, d7P2);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d7P2);
	xmlrpc_value *d7P3 = xmlrpc_double_new(&env, tvel);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP7, d7P3);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d7P3);
	xmlrpc_value *d7P4 = xmlrpc_double_new(&env, tacc);
	dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP7, d7P4);
    dieIfFaultOccurred(&env);
	xmlrpc_DECREF(d7P4);	
	
	arrayP8 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 4; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, epos_t->ePos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP8, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP9 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	xmlrpc_value *d10P1 = xmlrpc_double_new(&env, offset_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP9, d10P1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d10P1);
	xmlrpc_value *d10P2 = xmlrpc_double_new(&env, offset_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP9, d10P2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d10P2);
 	xmlrpc_value *d10P3 = xmlrpc_double_new(&env, offset_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP9, d10P3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d10P3);   
	xmlrpc_value *d10P4 = xmlrpc_double_new(&env, offset_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP9, d10P4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d10P4);
	xmlrpc_value *d10P5 = xmlrpc_double_new(&env, offset_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP9, d10P5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d10P5);
	xmlrpc_value *d10P6 = xmlrpc_double_new(&env, offset_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP9, d10P6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d10P6);	

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(AAAAAAAAdiA)",arrayP1,arrayP2,arrayP3,arrayP4,arrayP5,arrayP6,arrayP7,arrayP8,(xmlrpc_double)ovl,(xmlrpc_int32)offset_flag,arrayP9);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	
}
	
/**
 * @brief  笛卡尔空间螺旋线运动
 * @param  [in] joint_pos  目标关节位置,单位deg
 * @param  [in] desc_pos   目标笛卡尔位姿
 * @param  [in] tool  工具坐标号，范围[1~15]
 * @param  [in] user  工件坐标号，范围[1~15]
 * @param  [in] vel  速度百分比，范围[0~100]
 * @param  [in] acc  加速度百分比，范围[0~100],暂不开放
 * @param  [in] epos  扩展轴位置，单位mm
 * @param  [in] ovl  速度缩放因子，范围[0~100]	 
 * @param  [in] offset_flag  0-不偏移，1-基坐标系/工件坐标系下偏移，2-工具坐标系下偏移
 * @param  [in] offset_pos  位姿偏移量
 * @param  [in] spiral_param  螺旋参数
 * @return  错误码
 */
errno_t  FRRobot::NewSpiral(JointPos *joint_pos, DescPose *desc_pos, int tool, int user, float vel, float acc, ExaxisPos *epos, float ovl, uint8_t offset_flag, DescPose *offset_pos, SpiralParam spiral_param)
{
    const char * const methodName = "NewSpiral";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP1,*arrayP2,*arrayP3,*arrayP4,*arrayP5;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos->jPos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP1, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP2 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

	arrayP3 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 4; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, epos->ePos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP3, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP4 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	xmlrpc_value *d4P1 = xmlrpc_double_new(&env, offset_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d4P1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d4P1);
	xmlrpc_value *d4P2 = xmlrpc_double_new(&env, offset_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d4P2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d4P2);
 	xmlrpc_value *d4P3 = xmlrpc_double_new(&env, offset_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d4P3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d4P3);   
	xmlrpc_value *d4P4 = xmlrpc_double_new(&env, offset_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d4P4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d4P4);
	xmlrpc_value *d4P5 = xmlrpc_double_new(&env, offset_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d4P5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d4P5);
	xmlrpc_value *d4P6 = xmlrpc_double_new(&env, offset_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d4P6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d4P6);

	arrayP5 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);   

	xmlrpc_value *d5P1 = xmlrpc_double_new(&env, (double)spiral_param.circle_num);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P1);
	xmlrpc_value *d5P2 = xmlrpc_double_new(&env, spiral_param.circle_angle);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P2);
	xmlrpc_value *d5P3 = xmlrpc_double_new(&env, spiral_param.rad_init);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P3);
	xmlrpc_value *d5P4 = xmlrpc_double_new(&env, spiral_param.rad_add);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P4);
	xmlrpc_value *d5P5 = xmlrpc_double_new(&env, spiral_param.rotaxis_add);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P5);
	xmlrpc_value *d5P6 = xmlrpc_double_new(&env, (double)spiral_param.rot_direction);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP4, d5P6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d5P6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(AAiiddAdiAA)",arrayP1,arrayP2,(xmlrpc_int32)tool,(xmlrpc_int32)user,(xmlrpc_double)vel,(xmlrpc_double)acc,arrayP3,(xmlrpc_double)ovl,(xmlrpc_int32)offset_flag,arrayP4,arrayP5);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;		   
}

/**
 * @brief 伺服运动开始，配合ServoJ、ServoCart指令使用
 * @return  错误码
 */
errno_t FRRobot::ServoMoveStart()
{
    const char * const methodName = "ServoMoveStart";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();       

    return errcode;  
}

/**
 * @brief 伺服运动结束，配合ServoJ、ServoCart指令使用
 * @return  错误码
 */
errno_t FRRobot::ServoMoveEnd()
{
    const char * const methodName = "ServoMoveEnd";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();       

    return errcode;  
}
	
/**
 * @brief  关节空间伺服模式运动
 * @param  [in] joint_pos  目标关节位置,单位deg
 * @param  [in] acc  加速度百分比，范围[0~100],暂不开放，默认为0
 * @param  [in] vel  速度百分比，范围[0~100]，暂不开放，默认为0
 * @param  [in] cmdT  指令下发周期，单位s，建议范围[0.001~0.0016]
 * @param  [in] filterT 滤波时间，单位s，暂不开放，默认为0
 * @param  [in] gain  目标位置的比例放大器，暂不开放，默认为0
 * @return  错误码
 */
errno_t  FRRobot::ServoJ(JointPos *joint_pos, float acc, float vel, float cmdT, float filterT, float gain)
{
    const char * const methodName = "ServoJ";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos->jPos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(Addddd)",arrayP,(xmlrpc_double)acc,(xmlrpc_double)vel,(xmlrpc_double)cmdT,(xmlrpc_double)filterT,(xmlrpc_double)gain);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;		   
}

/**
 * @brief  笛卡尔空间伺服模式运动
 * @param  [in]  mode  0-绝对运动(基坐标系)，1-增量运动(基坐标系)，2-增量运动(工具坐标系)
 * @param  [in]  desc_pos  目标笛卡尔位姿或位姿增量
 * @param  [in]  pos_gain  位姿增量比例系数，仅在增量运动下生效，范围[0~1]
 * @param  [in] acc  加速度百分比，范围[0~100],暂不开放，默认为0
 * @param  [in] vel  速度百分比，范围[0~100]，暂不开放，默认为0
 * @param  [in] cmdT  指令下发周期，单位s，建议范围[0.001~0.0016]
 * @param  [in] filterT 滤波时间，单位s，暂不开放，默认为0
 * @param  [in] gain  目标位置的比例放大器，暂不开放，默认为0
 * @return  错误码
 */
errno_t  FRRobot::ServoCart(int mode, DescPose *desc_pose, float pos_gain[6], float acc, float vel, float cmdT, float filterT, float gain)
{
    const char * const methodName = "ServoCart";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP1,*arrayP2;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pose->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pose->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pose->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pose->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pose->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pose->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);	

	arrayP2 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, pos_gain[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP2, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iAAddddd)", mode,arrayP1,arrayP2,(xmlrpc_double)acc,(xmlrpc_double)vel,(xmlrpc_double)cmdT,(xmlrpc_double)filterT,(xmlrpc_double)gain);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}

/**
/**
 * @brief  关节扭矩控制开始
 * @return  错误码
 *
errno_t  FRRobot::ServoJTStart()
{
    const char * const methodName = "ServoJTStart";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);        
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();       

    return errcode;  
}

/**
 * @brief  关节扭矩控制
 * @param  [in]  torque j1~j6关节扭矩，单位Nm
 * @param  [in]  interval 指令周期，单位s，范围[0.001~0.008]
 * @return  错误码
 /
errno_t  FRRobot::ServoJT(double torque[6], double interval)
{
    const char * const methodName = "ServoJT";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, torque[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(Ad)",arrayP, interval);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;		 
}

/**
 * @brief  关节扭矩控制结束 
 * @return  错误码
 *
errno_t  FRRobot::ServoJTEnd()
{
    const char * const methodName = "ServoJTEnd";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();       

    return errcode;  
}
*/
   
/**
 * @brief  笛卡尔空间点到点运动
 * @param  [in]  desc_pos  目标笛卡尔位姿或位姿增量
 * @param  [in] tool  工具坐标号，范围[1~15]
 * @param  [in] user  工件坐标号，范围[1~15]
 * @param  [in] vel  速度百分比，范围[0~100]
 * @param  [in] acc  加速度百分比，范围[0~100],暂不开放
 * @param  [in] ovl  速度缩放因子，范围[0~100]
 * @param  [in] blendT [-1.0]-运动到位(阻塞)，[0~500.0]-平滑时间(非阻塞)，单位ms	
 * @param  [in] config  关节空间配置，[-1]-参考当前关节位置解算，[0~7]-参考特定关节空间配置解算，默认为-1	 
 * @return  错误码
 */
errno_t  FRRobot::MoveCart(DescPose *desc_pos, int tool, int user, float vel, float acc, float ovl, float blendT, int config)
{
    const char * const methodName = "MoveCart";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(Aiiddddi)",arrayP,(xmlrpc_int32)tool,(xmlrpc_int32)user,(xmlrpc_double)vel,(xmlrpc_double)acc,(xmlrpc_double)ovl,(xmlrpc_double)blendT,(xmlrpc_int32)config);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;		
}
	
/**
 * @brief  样条运动开始
 * @return  错误码
 */
errno_t  FRRobot::SplineStart()
{
    const char * const methodName = "SplineStart";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}

/**
 * @brief  关节空间样条运动
 * @param  [in] joint_pos  目标关节位置,单位deg
 * @param  [in] desc_pos   目标笛卡尔位姿
 * @param  [in] tool  工具坐标号，范围[1~15]
 * @param  [in] user  工件坐标号，范围[1~15]
 * @param  [in] vel  速度百分比，范围[0~100]
 * @param  [in] acc  加速度百分比，范围[0~100],暂不开放
 * @param  [in] ovl  速度缩放因子，范围[0~100]	
 * @return  错误码
 */
errno_t  FRRobot::SplinePTP(JointPos *joint_pos, DescPose *desc_pos, int tool, int user, float vel, float acc, float ovl)
{
    const char * const methodName = "SplinePTP";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP1,*arrayP2;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos->jPos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP1, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP2 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(AAiiddd)",arrayP1,arrayP2,(xmlrpc_int32)tool,(xmlrpc_int32)user,(xmlrpc_double)vel,(xmlrpc_double)acc,(xmlrpc_double)ovl);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}
	
/**
 * @brief  样条运动结束
 * @return  错误码
 */
errno_t  FRRobot::SplineEnd()
{
    const char * const methodName = "SplineEnd";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}
	
/**
 * @brief 新样条运动开始
 * @param  [in] type   0-圆弧过渡，1-给定点位为路径点
 * @return  错误码
 */
errno_t  FRRobot::NewSplineStart(int type)
{
    const char * const methodName = "NewSplineStart";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)type);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	      
}
	
/**
 * @brief 新样条指令点
 * @param  [in] joint_pos  目标关节位置,单位deg
 * @param  [in] desc_pos   目标笛卡尔位姿
 * @param  [in] tool  工具坐标号，范围[1~15]
 * @param  [in] user  工件坐标号，范围[1~15]
 * @param  [in] vel  速度百分比，范围[0~100]
 * @param  [in] acc  加速度百分比，范围[0~100],暂不开放
 * @param  [in] ovl  速度缩放因子，范围[0~100]
 * @param  [in] blendR [-1.0]-运动到位(阻塞)，[0~1000.0]-平滑半径(非阻塞)，单位mm
 * @return  错误码
 */	 
errno_t  FRRobot::NewSplinePoint(JointPos *joint_pos, DescPose *desc_pos, int tool, int user, float vel, float acc, float ovl, float blendR, int lastFlag)
{
    const char * const methodName = "NewSplinePoint";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP1,*arrayP2;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos->jPos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP1, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP2 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(AAiiddddi)",arrayP1,arrayP2,(xmlrpc_int32)tool,(xmlrpc_int32)user,(xmlrpc_double)vel,(xmlrpc_double)acc,(xmlrpc_double)ovl, (xmlrpc_double)blendR, (xmlrpc_int32)lastFlag);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	      
}
	
/**
 * @brief 新样条运动结束
 * @return  错误码
 */
errno_t  FRRobot::NewSplineEnd()
{
    const char * const methodName = "NewSplineEnd";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	        
}
	
/**
 * @brief 终止运动
 * @return  错误码
 */
errno_t  FRRobot::StopMotion()
{
    int errcode = 0;
    static int cnt = 0;

    bzero(g_sendbuf, BUFFER_SIZE);
    sprintf(g_sendbuf, "/f/bIII%dIII102III4IIISTOPIII/b/f", cnt);
    cnt++;
    is_sendcmd = true;

    printf("FR stopMotion\n");
    
    return errcode;	    
}

/**
 * @brief 暂停运动
 * @return  错误码
 */
errno_t  FRRobot::PauseMotion()
{
    int errcode = 0;
    static int cnt = 0;

    bzero(g_sendbuf, BUFFER_SIZE);
    sprintf(g_sendbuf, "/f/bIII%dIII103III5IIIPAUSEIII/b/f", cnt);
    cnt++;
    is_sendcmd = true;
    
    return errcode;	   
}

/**
 * @brief 恢复运动
 * @return  错误码
 */
errno_t  FRRobot::ResumeMotion()
{
    int errcode = 0;
    static int cnt = 0;

    bzero(g_sendbuf, BUFFER_SIZE);
    sprintf(g_sendbuf, "/f/bIII%dIII104III6IIIRESUMEIII/b/f", cnt);
    cnt++;
    is_sendcmd = true;
    
    return errcode;	   
}


	
/**
 * @brief  点位整体偏移开始
 * @param  [in]  flag  0-基坐标系下/工件坐标系下偏移，2-工具坐标系下偏移
 * @param  [in] offset_pos  位姿偏移量
 * @return  错误码
 */
errno_t  FRRobot::PointsOffsetEnable(int flag, DescPose *offset_pos)
{
    const char * const methodName = "PointsOffsetEnable";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, offset_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, offset_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, offset_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, offset_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, offset_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, offset_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iA)",flag,arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	       
}
	
/**
 * @brief  点位整体偏移结束
 * @return  错误码
 */
errno_t  FRRobot::PointsOffsetDisable()
{
    const char * const methodName = "PointsOffsetDisable";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	       
}

/**
 * @brief  设置控制箱数字量输出
 * @param  [in] id  io编号，范围[0~15]
 * @param  [in] status 0-关，1-开
 * @param  [in] smooth 0-不平滑， 1-平滑
 * @param  [in] block  0-阻塞，1-非阻塞
 * @return  错误码
 */
errno_t  FRRobot::SetDO(int id, uint8_t status, uint8_t smooth, uint8_t block)
{
    const char * const methodName = "SetDO";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iiii)",(xmlrpc_int32)id, (xmlrpc_int32)status, (xmlrpc_int32)smooth, (xmlrpc_int32)block);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}

/**
 * @brief  设置工具数字量输出
 * @param  [in] id  io编号，范围[0~1]
 * @param  [in] status 0-关，1-开
 * @param  [in] smooth 0-不平滑， 1-平滑
 * @param  [in] block  0-阻塞，1-非阻塞
 * @return  错误码
 */
errno_t  FRRobot::SetToolDO(int id, uint8_t status, uint8_t smooth, uint8_t block)
{
    const char * const methodName = "SetToolDO";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iiii)",(xmlrpc_int32)id, (xmlrpc_int32)status, (xmlrpc_int32)smooth, (xmlrpc_int32)block);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	 
}

/**
 * @brief  设置控制箱模拟量输出
 * @param  [in] id  io编号，范围[0~1]
 * @param  [in] value 电流或电压值百分比，范围[0~100]对应电流值[0~20mA]或电压[0~10V]
 * @param  [in] block  0-阻塞，1-非阻塞
 * @return  错误码
 */
errno_t  FRRobot::SetAO(int id, float value, uint8_t block)
{
    const char * const methodName = "SetAO";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(idi)",(xmlrpc_int32)id, (xmlrpc_double)value, (xmlrpc_int32)block);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}

/**
 * @brief  设置工具模拟量输出
 * @param  [in] id  io编号，范围[0]
 * @param  [in] value 电流或电压值百分比，范围[0~100]对应电流值[0~20mA]或电压[0~10V]
 * @param  [in] block  0-阻塞，1-非阻塞
 * @return  错误码
 */
errno_t  FRRobot::SetToolAO(int id, float value, uint8_t block)
{
    const char * const methodName = "SetToolAO";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(idi)",(xmlrpc_int32)id, (xmlrpc_double)value, (xmlrpc_int32)block);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}

/**
 * @brief  获取控制箱数字量输入
 * @param  [in] id  io编号，范围[0~15]
 * @param  [in] block  0-阻塞，1-非阻塞
 * @param  [out] result  0-低电平，1-高电平
 * @return  错误码
 */	
errno_t  FRRobot::GetDI(int id, uint8_t block, uint8_t *result)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        if(id >= 0 && id < 8)
        {
            *result = (robot_state_pkg.cl_dgt_input_l & (0x01 << id)) >> id;
        }
        else if(id >=8 && id < 16)
        {
            id -= 8;
            *result = (robot_state_pkg.cl_dgt_input_h & (0x01 << id)) >> id;
        }
        else
        {
            *result = 0;
            errcode = -1;
        }
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	   
}

/**
 * @brief  获取工具数字量输入
 * @param  [in] id  io编号，范围[0~1]
 * @param  [in] block  0-阻塞，1-非阻塞
 * @param  [out] result  0-低电平，1-高电平
 * @return  错误码
 */	
errno_t  FRRobot::GetToolDI(int id, uint8_t block, uint8_t *result)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        if(id >= 0 && id < 2)
        {
            id += 1;
            *result = (robot_state_pkg.tl_dgt_input_l & (0x01 << id)) >> id;
        }
        else
        {
            *result = 0;
            errcode = -1;
        }
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	      
}
	
/**
 * @brief 等待控制箱数字量输入
 * @param  [in] id  io编号，范围[0~15]
 * @param  [in]  status 0-关，1-开
 * @param  [in]  max_time  最大等待时间，单位ms
 * @param  [in]  opt  超时后策略，0-程序停止并提示超时，1-忽略超时提示程序继续执行，2-一直等待
 * @return  错误码
 */
errno_t  FRRobot::WaitDI(int id, uint8_t status, int max_time, int opt)
{
    const char * const methodName = "WaitDI";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iiii)",(xmlrpc_int32)id, (xmlrpc_int32)status, (xmlrpc_int32)max_time, (xmlrpc_int32)opt);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	 
}

/**
 * @brief 等待控制箱多路数字量输入
 * @param  [in] mode 0-多路与，1-多路或
 * @param  [in] id  io编号，bit0~bit7对应DI0~DI7，bit8~bit15对应CI0~CI7
 * @param  [in]  status 0-关，1-开
 * @param  [in]  max_time  最大等待时间，单位ms
 * @param  [in]  opt  超时后策略，0-程序停止并提示超时，1-忽略超时提示程序继续执行，2-一直等待
 * @return  错误码
 */
errno_t  FRRobot::WaitMultiDI(int mode, int id, uint8_t status, int max_time, int opt)
{
    const char * const methodName = "WaitMultiDI";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iiiii)",(xmlrpc_int32)mode, (xmlrpc_int32)id, (xmlrpc_int32)status, (xmlrpc_int32)max_time, (xmlrpc_int32)opt);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}

/**
 * @brief 等待工具数字量输入
 * @param  [in] id  io编号，范围[0~1]
 * @param  [in]  status 0-关，1-开
 * @param  [in]  max_time  最大等待时间，单位ms
 * @param  [in]  opt  超时后策略，0-程序停止并提示超时，1-忽略超时提示程序继续执行，2-一直等待
 * @return  错误码
 */
errno_t  FRRobot::WaitToolDI(int id, uint8_t status, int max_time, int opt)
{
    const char * const methodName = "WaitToolDI";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iiii)", (xmlrpc_int32)id, (xmlrpc_int32)status, (xmlrpc_int32)max_time, (xmlrpc_int32)opt);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	      
}
	
/**
 * @brief  获取控制箱模拟量输入
 * @param  [in] id  io编号，范围[0~1]
 * @param  [in] block  0-阻塞，1-非阻塞
 * @param  [out] result  输入电流或电压值百分比，范围[0~100]对应电流值[0~20mS]或电压[0~10V]
 * @return  错误码
 */	
errno_t  FRRobot::GetAI(int id, uint8_t block, float *result)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        if(id >=0 && id < 2)
        {
            *result = robot_state_pkg.cl_analog_input[id];
        }
        else
        {
            *result = 0;
            errcode = -1;
        }
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	        
}	

/**
 * @brief  获取工具模拟量输入
 * @param  [in] id  io编号，范围[0]
 * @param  [in] block  0-阻塞，1-非阻塞
 * @param  [out] result  输入电流或电压值百分比，范围[0~100]对应电流值[0~20mS]或电压[0~10V]
 * @return  错误码
 */	
errno_t  FRRobot::GetToolAI(int id, uint8_t block, float *result)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *result = robot_state_pkg.tl_anglog_input;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	     
}

/**
 * @brief 获取机器人末端点记录按钮状态
 * @param [out] state 按钮状态，0-按下，1-松开
 * @return 错误码
 */
errno_t  FRRobot::GetAxlePointRecordBtnState(uint8_t *state)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *state = (robot_state_pkg.tl_dgt_input_l & 0x10)>>4;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	   
}

/**
 * @brief 获取机器人末端DO输出状态
 * @param [out] do_state DO输出状态，do0~do1对应bit1~bit2,从bit0开始
 * @return 错误码
 */
errno_t  FRRobot::GetToolDO(uint8_t *do_state)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *do_state = robot_state_pkg.tl_dgt_output_l;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	     
}

/**
 * @brief 获取机器人控制器DO输出状态
 * @param [out] do_state_h DO输出状态，co0~co7对应bit0~bit7
 * @param [out] do_state_l DO输出状态，do0~do7对应bit0~bit7
 * @return 错误码
 */
errno_t  FRRobot::GetDO(uint8_t *do_state_h, uint8_t *do_state_l)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *do_state_h = robot_state_pkg.cl_dgt_output_h;
        *do_state_l = robot_state_pkg.cl_dgt_output_l;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	    
}
	
/**
 * @brief 等待控制箱模拟量输入
 * @param  [in] id  io编号，范围[0~1]
 * @param  [in]  sign 0-大于，1-小于
 * @param  [in]  value 输入电流或电压值百分比，范围[0~100]对应电流值[0~20mS]或电压[0~10V]
 * @param  [in]  max_time  最大等待时间，单位ms
 * @param  [in]  opt  超时后策略，0-程序停止并提示超时，1-忽略超时提示程序继续执行，2-一直等待
 * @return  错误码
 */
errno_t  FRRobot::WaitAI(int id, int sign, float value, int max_time, int opt)
{
    const char * const methodName = "WaitAI";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iidii)", (xmlrpc_int32)id, (xmlrpc_int32)sign, (xmlrpc_double)value, (xmlrpc_int32)max_time, (xmlrpc_int32)opt);
	errcode =dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}
	
/**
 * @brief 等待工具模拟量输入
 * @param  [in] id  io编号，范围[0]
 * @param  [in]  sign 0-大于，1-小于
 * @param  [in]  value 输入电流或电压值百分比，范围[0~100]对应电流值[0~20mS]或电压[0~10V]
 * @param  [in]  max_time  最大等待时间，单位ms
 * @param  [in]  opt  超时后策略，0-程序停止并提示超时，1-忽略超时提示程序继续执行，2-一直等待
 * @return  错误码
 */
errno_t  FRRobot::WaitToolAI(int id, int sign, float value, int max_time, int opt)
{
    const char * const methodName = "WaitToolAI";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iidii)", (xmlrpc_int32)id, (xmlrpc_int32)sign, (xmlrpc_double)value, (xmlrpc_int32)max_time, (xmlrpc_int32)opt);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	       
}

/**
 * @brief  设置全局速度
 * @param  [in]  vel  速度百分比，范围[0~100]
 * @return  错误码
 */
errno_t  FRRobot::SetSpeed(int vel)
{
    const char * const methodName = "SetSpeed";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)",(xmlrpc_int32)vel);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	       
}
	
/**
 * @brief  设置系统变量值
 * @param  [in]  id  变量编号，范围[1~20]
 * @param  [in]  value 变量值
 * @return  错误码
 */
errno_t  FRRobot::SetSysVarValue(int id, float value)
{
    const char * const methodName = "SetSysVarValue";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(id)",(xmlrpc_int32)id, (xmlrpc_double)value);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}

/**
 * @brief 设置工具参考点-六点法
 * @param [in] point_num 点编号,范围[1~6] 
 * @return 错误码
 */
errno_t FRRobot::SetToolPoint(int point_num)
{
    const char * const methodName = "SetToolPoint";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)",(xmlrpc_int32)point_num);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}

/**
 * @brief  计算工具坐标系
 * @param [out] tcp_pose 工具坐标系
 * @return 错误码
 */
errno_t FRRobot::ComputeTool(DescPose *tcp_pose)
{
    const char * const methodName = "ComputeTool";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&tcp_pose->tran.x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&tcp_pose->tran.y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&tcp_pose->tran.z);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 4);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP4, (xmlrpc_double*)&tcp_pose->rpy.rx);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP5 = xmlrpc_array_get_item(&env, resultP, 5);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP5, (xmlrpc_double*)&tcp_pose->rpy.ry);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP6 = xmlrpc_array_get_item(&env, resultP, 6);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP6, (xmlrpc_double*)&tcp_pose->rpy.rz);
    dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}

/**
 * @brief 设置工具参考点-四点法
 * @param [in] point_num 点编号,范围[1~4] 
 * @return 错误码
 */
errno_t FRRobot::SetTcp4RefPoint(int point_num)
{
    const char * const methodName = "SetTcp4RefPoint";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)",(xmlrpc_int32)point_num);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}

/**
 * @brief  计算工具坐标系
 * @param [out] tcp_pose 工具坐标系
 * @return 错误码
 */
errno_t FRRobot::ComputeTcp4(DescPose *tcp_pose)
{
    const char * const methodName = "ComputeTcp4";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&tcp_pose->tran.x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&tcp_pose->tran.y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&tcp_pose->tran.z);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 4);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP4, (xmlrpc_double*)&tcp_pose->rpy.rx);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP5 = xmlrpc_array_get_item(&env, resultP, 5);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP5, (xmlrpc_double*)&tcp_pose->rpy.ry);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP6 = xmlrpc_array_get_item(&env, resultP, 6);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP6, (xmlrpc_double*)&tcp_pose->rpy.rz);
    dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}
	
/**
 * @brief  设置工具坐标系
 * @param  [in] id 坐标系编号，范围[1~15]
 * @param  [in] coord  工具中心点相对于末端法兰中心位姿
 * @param  [in] type  0-工具坐标系，1-传感器坐标系
 * @param  [in] install 安装位置，0-机器人末端，1-机器人外部
 * @return  错误码
 */
errno_t  FRRobot::SetToolCoord(int id, DescPose *coord, int type, int install)
{
    const char * const methodName = "SetToolCoord";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, coord->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, coord->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, coord->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, coord->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, coord->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, coord->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iAii)",(xmlrpc_int32)id, arrayP, (xmlrpc_int32)type, (xmlrpc_int32)install);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	       
}
	
/**
 * @brief  设置工具坐标系列表
 * @param  [in] id 坐标系编号，范围[1~15]
 * @param  [in] coord  工具中心点相对于末端法兰中心位姿
 * @param  [in] type  0-工具坐标系，1-传感器坐标系
 * @param  [in] install 安装位置，0-机器人末端，1-机器人外部
 * @return  错误码
 */
errno_t  FRRobot::SetToolList(int id, DescPose *coord, int type, int install)
{
    const char * const methodName = "SetToolList";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, coord->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, coord->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, coord->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, coord->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, coord->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, coord->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iAii)",(xmlrpc_int32)id, arrayP, (xmlrpc_int32)type, (xmlrpc_int32)install);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	 
}

/**
 * @brief 设置外部工具参考点-六点法
 * @param [in] point_num 点编号,范围[1~6] 
 * @return 错误码
 */
errno_t FRRobot::SetExTCPPoint(int point_num)
{
    const char * const methodName = "SetExTCPPoint";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)",(xmlrpc_int32)point_num);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}

/**
 * @brief  计算外部工具坐标系
 * @param [out] tcp_pose 工具坐标系
 * @return 错误码
 */
errno_t FRRobot::ComputeExTCF(DescPose *tcp_pose)
{
    const char * const methodName = "ComputeExTCF";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&tcp_pose->tran.x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&tcp_pose->tran.y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&tcp_pose->tran.z);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 4);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP4, (xmlrpc_double*)&tcp_pose->rpy.rx);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP5 = xmlrpc_array_get_item(&env, resultP, 5);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP5, (xmlrpc_double*)&tcp_pose->rpy.ry);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP6 = xmlrpc_array_get_item(&env, resultP, 6);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP6, (xmlrpc_double*)&tcp_pose->rpy.rz);
    dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}

	
/**
 * @brief  设置外部工具坐标系
 * @param  [in] id 坐标系编号，范围[1~15]
 * @param  [in] etcp  工具中心点相对末端法兰中心位姿
 * @param  [in] etool  待定
 * @return  错误码
 */
errno_t  FRRobot::SetExToolCoord(int id, DescPose *etcp, DescPose *etool)
{
    const char * const methodName = "SetExToolCoord";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP1,*arrayP2;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, etcp->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, etcp->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, etcp->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, etcp->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, etcp->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, etcp->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

	arrayP2 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *d2P1 = xmlrpc_double_new(&env, etool->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, d2P1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d2P1);
	xmlrpc_value *d2P2 = xmlrpc_double_new(&env, etool->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, d2P2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d2P2);
 	xmlrpc_value *d2P3 = xmlrpc_double_new(&env, etool->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, d2P3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d2P3);   
	xmlrpc_value *d2P4 = xmlrpc_double_new(&env, etool->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, d2P4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d2P4);
	xmlrpc_value *d2P5 = xmlrpc_double_new(&env, etool->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, d2P5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d2P5);
	xmlrpc_value *d2P6 = xmlrpc_double_new(&env, etool->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, d2P6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d2P6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iAA)",(xmlrpc_int32)id, arrayP1, arrayP2);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	 
}
	
/**
 * @brief  设置外部工具坐标系列表
 * @param  [in] id 坐标系编号，范围[1~15]
 * @param  [in] etcp  工具中心点相对末端法兰中心位姿
 * @param  [in] etool  待定
 * @return  错误码
 */
errno_t  FRRobot::SetExToolList(int id, DescPose *etcp, DescPose *etool)
{
    const char * const methodName = "SetExToolList";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP1,*arrayP2;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, etcp->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, etcp->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, etcp->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, etcp->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, etcp->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, etcp->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

	arrayP2 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *d2P1 = xmlrpc_double_new(&env, etool->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, d2P1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d2P1);
	xmlrpc_value *d2P2 = xmlrpc_double_new(&env, etool->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, d2P2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d2P2);
 	xmlrpc_value *d2P3 = xmlrpc_double_new(&env, etool->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, d2P3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d2P3);   
	xmlrpc_value *d2P4 = xmlrpc_double_new(&env, etool->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, d2P4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d2P4);
	xmlrpc_value *d2P5 = xmlrpc_double_new(&env, etool->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, d2P5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d2P5);
	xmlrpc_value *d2P6 = xmlrpc_double_new(&env, etool->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, d2P6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(d2P6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iAA)",(xmlrpc_int32)id, arrayP1, arrayP2);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}


/**
 * @brief 设置工件参考点-三点法
 * @param [in] point_num 点编号,范围[1~3] 
 * @return 错误码
 */
errno_t FRRobot::SetWObjCoordPoint(int point_num)
{
    const char * const methodName = "SetWObjCoordPoint";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)",(xmlrpc_int32)point_num);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}

/**
 * @brief  计算工件坐标系
 * @param [out] wobj_pose 工件坐标系
 * @return 错误码
 */
errno_t FRRobot::ComputeWObjCoord(DescPose *wobj_pose)
{
    const char * const methodName = "ComputeWObjCoord";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&wobj_pose->tran.x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&wobj_pose->tran.y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&wobj_pose->tran.z);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 4);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP4, (xmlrpc_double*)&wobj_pose->rpy.rx);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP5 = xmlrpc_array_get_item(&env, resultP, 5);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP5, (xmlrpc_double*)&wobj_pose->rpy.ry);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP6 = xmlrpc_array_get_item(&env, resultP, 6);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP6, (xmlrpc_double*)&wobj_pose->rpy.rz);
    dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}

/**
 * @brief  设置工件坐标系
 * @param  [in] id 坐标系编号，范围[1~15]
 * @param  [in] coord  工件坐标系相对于末端法兰中心位姿
 * @return  错误码
 */	 
errno_t  FRRobot::SetWObjCoord(int id, DescPose *coord)
{
    const char * const methodName = "SetWObjCoord";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, coord->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, coord->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, coord->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, coord->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, coord->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, coord->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iA)",(xmlrpc_int32)id, arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}
	
/**
 * @brief  设置工件坐标系列表
 * @param  [in] id 坐标系编号，范围[1~15]
 * @param  [in] coord  工件坐标系相对于末端法兰中心位姿
 * @return  错误码
 */	 
errno_t  FRRobot::SetWObjList(int id, DescPose *coord)
{
    const char * const methodName = "SetWObjList";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, coord->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, coord->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, coord->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, coord->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, coord->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, coord->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iA)",(xmlrpc_int32)id, arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	
}
	
/**
 * @brief  设置末端负载重量
 * @param  [in] weight  负载重量，单位kg
 * @return  错误码
 */
errno_t  FRRobot::SetLoadWeight(float weight)
{
    const char * const methodName = "SetLoadWeight";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(d)", (xmlrpc_double)weight);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	       
}
	
/**
 * @brief  设置末端负载质心坐标
 * @param  [in] coord 质心坐标，单位mm
 * @return  错误码
 */
errno_t  FRRobot::SetLoadCoord(DescTran *coord)
{
    const char * const methodName = "SetLoadCoord";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env); 
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(ddd)", (xmlrpc_double)coord->x, (xmlrpc_double)coord->y, (xmlrpc_double)coord->z);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}

/**
 * @brief  设置机器人安装方式
 * @param  [in] install  安装方式，0-正装，1-侧装，2-倒装
 * @return  错误码
 */
errno_t  FRRobot::SetRobotInstallPos(uint8_t install)
{
    const char * const methodName = "SetRobotInstallPos";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)install);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP); 
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}

/**
 * @brief  设置机器人安装角度，自由安装
 * @param  [in] yangle  倾斜角
 * @param  [in] zangle  旋转角
 * @return  错误码
 */
errno_t  FRRobot::SetRobotInstallAngle(double yangle, double zangle)
{
    const char * const methodName = "SetRobotInstallAngle";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(dd)", yangle, zangle);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}
	
/**
 * @brief  等待指定时间
 * @param  [in]  t_ms  单位ms
 * @return  错误码
 */
errno_t  FRRobot::WaitMs(int t_ms)
{
    const char * const methodName = "WaitMs";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)t_ms);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	        
}
	
/**
 * @brief 设置碰撞等级
 * @param  [in]  mode  0-等级，1-百分比
 * @param  [in]  level 碰撞阈值，等级对应范围[],百分比对应范围[0~1]
 * @param  [in]  config 0-不更新配置文件，1-更新配置文件
 * @return  错误码
 */
errno_t  FRRobot::SetAnticollision(int mode, float level[6], int config)
{
    const char * const methodName = "SetAnticollision";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, level[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}   
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iAi)", (xmlrpc_int32)mode, arrayP, (xmlrpc_int32)config);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}
	
/**
 * @brief  设置碰撞后策略
 * @param  [in] strategy  0-报错停止，1-继续运行
 * @return  错误码	 
 */
errno_t  FRRobot::SetCollisionStrategy(int strategy)
{
    const char * const methodName = "SetCollisionStrategy";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)strategy);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}
	
/**
 * @brief  设置正限位
 * @param  [in] limit 六个关节位置，单位deg
 * @return  错误码
 */
errno_t  FRRobot::SetLimitPositive(float limit[6])
{
    const char * const methodName = "SetLimitPositive";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, limit[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}   
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(A)", arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	       
}
	
/**
 * @brief  设置负限位
 * @param  [in] limit 六个关节位置，单位deg
 * @return  错误码
 */
errno_t  FRRobot::SetLimitNegative(float limit[6])
{
    const char * const methodName = "SetLimitNegative";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, limit[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}   
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(A)", arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	          
}
	
/**
 * @brief  错误状态清除
 * @return  错误码
 */
errno_t  FRRobot::ResetAllError()
{
    int errcode = 0;
    static int cnt = 0;

    bzero(g_sendbuf, BUFFER_SIZE);
    sprintf(g_sendbuf, "/f/bIII%dIII107III13IIIRESETALLERRORIII/b/f", cnt);
    cnt++;
    is_sendcmd = true;
    
    return errcode;	  
}
	
/**
 * @brief  关节摩擦力补偿开关
 * @param  [in]  state  0-关，1-开
 * @return  错误码
 */
errno_t  FRRobot::FrictionCompensationOnOff(uint8_t state)
{
    const char * const methodName = "FrictionCompensationOnOff";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)state);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}
	
/**
 * @brief  设置关节摩擦力补偿系数-正装
 * @param  [in]  coeff 六个关节补偿系数，范围[0~1]
 * @return  错误码
 */
errno_t  FRRobot::SetFrictionValue_level(float coeff[6])
{
    const char * const methodName = "SetFrictionValue_level";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, coeff[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}   
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(A)", arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	       
}

/**
 * @brief  设置关节摩擦力补偿系数-侧装
 * @param  [in]  coeff 六个关节补偿系数，范围[0~1]
 * @return  错误码
 */
errno_t  FRRobot::SetFrictionValue_wall(float coeff[6])
{
    const char * const methodName = "SetFrictionValue_wall";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, coeff[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}   
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(A)", arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}

/**
 * @brief  设置关节摩擦力补偿系数-倒装
 * @param  [in]  coeff 六个关节补偿系数，范围[0~1]
 * @return  错误码
 */
errno_t  FRRobot::SetFrictionValue_ceiling(float coeff[6])
{
    const char * const methodName = "SetFrictionValue_ceiling";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, coeff[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}   
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(A)", arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}

/**
 * @brief  设置关节摩擦力补偿系数-自由安装
 * @param  [in]  coeff 六个关节补偿系数，范围[0~1]
 * @return  错误码
 */
errno_t  FRRobot::SetFrictionValue_freedom(float coeff[6])
{
    const char * const methodName = "SetFrictionValue_freedom";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, coeff[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}   
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(A)", arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	      
}

/**
 * @brief  获取机器人安装角度
 * @param  [out] yangle 倾斜角
 * @param  [out] zangle 旋转角
 * @return  错误码
 */
errno_t  FRRobot::GetRobotInstallAngle(float *yangle, float *zangle)
{
    const char * const methodName = "GetRobotInstallAngle";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
	dieIfFaultOccurred(&env);
	
	xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);   
    xmlrpc_double yang; 
    xmlrpc_read_double(&env, strctP1, &yang);
    *yangle = yang;
	dieIfFaultOccurred(&env);	

 	xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
	dieIfFaultOccurred(&env);    
    xmlrpc_double zang;
    xmlrpc_read_double(&env, strctP2, &zang);
    *zangle = zang;
	dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}
	
/**
 * @brief  获取系统变量值
 * @param  [in] id 系统变量编号，范围[1~20]
 * @param  [out] value  系统变量值
 * @return  错误码
 */
errno_t  FRRobot::GetSysVarValue(int id, float *value)
{
    const char * const methodName = "GetSysVarValue";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)id);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
	dieIfFaultOccurred(&env);
	
	xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);  
    xmlrpc_double va;  
    xmlrpc_read_double(&env, strctP1, &va);
    *value = va;
	dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	      
}
	
/**
 * @brief  获取当前关节位置(角度)
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] jPos 六个关节位置，单位deg
 * @return  错误码
 */
errno_t  FRRobot::GetActualJointPosDegree(uint8_t flag, JointPos *jPos)
{
    int i;
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        for(i = 0; i < 6; i++)
        {
            jPos->jPos[i]=robot_state_pkg.jt_cur_pos[i];
        }
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	      
}


/**
 * @brief  获取关节反馈速度-deg/s
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] speed [x,y,z,rx,ry,rz]速度
 * @return  错误码 
 */	
errno_t  FRRobot::GetActualJointSpeedsDegree(uint8_t flag, float speed[6])
{
    int errcode = 0;
    int i;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        for(i = 0; i < 6; i++)
        {
            speed[i] = robot_state_pkg.actual_qd[i];
        }
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	   
}

/**
 * @brief  获取关节反馈加速度-deg/s^2
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] acc 六个关节加速度
 * @return  错误码 
 */	
errno_t  FRRobot::GetActualJointAccDegree(uint8_t flag, float acc[6])
{
    int errcode = 0;
    int i;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        for(i = 0; i < 6; i++)
        {
            acc[i] = robot_state_pkg.actual_qdd[i];
        }
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	       
} 


/**
 * @brief  获取TCP指令速度
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] tcp_speed 线性速度
 * @param  [out] ori_speed 姿态速度
 * @return  错误码 
 */
errno_t  FRRobot::GetTargetTCPCompositeSpeed(uint8_t flag, float *tcp_speed, float *ori_speed)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *tcp_speed = robot_state_pkg.target_TCP_CmpSpeed[0];
        *ori_speed = robot_state_pkg.target_TCP_CmpSpeed[1];        
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	   
}

/**
 * @brief  获取TCP反馈速度
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] tcp_speed 线性速度
 * @param  [out] ori_speed 姿态速度
 * @return  错误码 
 */	
errno_t  FRRobot::GetActualTCPCompositeSpeed(uint8_t flag, float *tcp_speed, float *ori_speed)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *tcp_speed = robot_state_pkg.actual_TCP_CmpSpeed[0];
        *ori_speed = robot_state_pkg.actual_TCP_CmpSpeed[1];
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	   
}

/**
 * @brief  获取TCP指令速度
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] speed [x,y,z,rx,ry,rz]速度
 * @return  错误码 
 */	
errno_t  FRRobot::GetTargetTCPSpeed(uint8_t flag, float speed[6])
{
    int errcode = 0;
    int i;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        for(i = 0; i < 6; i++)
        {
            speed[i] = robot_state_pkg.target_TCP_Speed[i];
        }
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	   
}

/**
 * @brief  获取TCP反馈速度
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] speed [x,y,z,rx,ry,rz]速度
 * @return  错误码 
 */	
errno_t  FRRobot::GetActualTCPSpeed(uint8_t flag, float speed[6])
{
    int errcode = 0;
    int i;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        for(i = 0; i < 6; i++)
        {
            speed[i] = robot_state_pkg.actual_TCP_Speed[i];
        }
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	    
}
	

/**
 * @brief  获取当前工具位姿
 * @param  [in] flag  0-阻塞，1-非阻塞
 * @param  [out] desc_pos  工具位姿
 * @return  错误码
 */
errno_t  FRRobot::GetActualTCPPose(uint8_t flag, DescPose *desc_pos)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        desc_pos->tran.x = robot_state_pkg.tl_cur_pos[0];
        desc_pos->tran.y = robot_state_pkg.tl_cur_pos[1];
        desc_pos->tran.z = robot_state_pkg.tl_cur_pos[2];
        desc_pos->rpy.rx = robot_state_pkg.tl_cur_pos[3];
        desc_pos->rpy.ry = robot_state_pkg.tl_cur_pos[4];
        desc_pos->rpy.rz = robot_state_pkg.tl_cur_pos[5];   
        //printf("tcp pose:%lf,%lf,%lf,%lf,%lf,%lf\n", robot_state_pkg.tl_cur_pos[0],robot_state_pkg.tl_cur_pos[1],robot_state_pkg.tl_cur_pos[2],robot_state_pkg.tl_cur_pos[3],robot_state_pkg.tl_cur_pos[4],robot_state_pkg.tl_cur_pos[5]);    
    }
    else
    {
        errcode = g_sock_com_err;
        //printf("get tcp pose error:%d\n", g_sock_com_err);
    }

    return errcode;	       
}
	
/**
 * @brief  获取当前工具坐标系编号
 * @param  [in] flag  0-阻塞，1-非阻塞
 * @param  [out] id  工具坐标系编号
 * @return  错误码
 */
errno_t  FRRobot::GetActualTCPNum(uint8_t flag, int *id)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *id = robot_state_pkg.tool;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	    
}
	
/**
 * @brief  获取当前工件坐标系编号
 * @param  [in] flag  0-阻塞，1-非阻塞
 * @param  [out] id  工件坐标系编号
 * @return  错误码
 */
errno_t  FRRobot::GetActualWObjNum(uint8_t flag, int *id)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *id = robot_state_pkg.user;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	     
}	
	
/**
 * @brief  获取当前末端法兰位姿
 * @param  [in] flag  0-阻塞，1-非阻塞
 * @param  [out] desc_pos  法兰位姿
 * @return  错误码
 */
errno_t  FRRobot::GetActualToolFlangePose(uint8_t flag, DescPose *desc_pos)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        desc_pos->tran.x = robot_state_pkg.flange_cur_pos[0];
        desc_pos->tran.y = robot_state_pkg.flange_cur_pos[1];
        desc_pos->tran.z = robot_state_pkg.flange_cur_pos[2];
        desc_pos->rpy.rx = robot_state_pkg.flange_cur_pos[3];
        desc_pos->rpy.ry = robot_state_pkg.flange_cur_pos[4];
        desc_pos->rpy.rz = robot_state_pkg.flange_cur_pos[5];
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	     
}	
	
/**
 * @brief  逆运动学求解
 * @param  [in] type 0-绝对位姿(基坐标系)，1-增量位姿(基坐标系)，2-增量位姿(工具坐标系)
 * @param  [in] desc_pos 笛卡尔位姿
 * @param  [in] config 关节空间配置，[-1]-参考当前关节位置解算，[0~7]-依据特定关节空间配置求解
 * @param  [out] joint_pos 关节位置
 * @return  错误码
 */
errno_t  FRRobot::GetInverseKin(int type, DescPose *desc_pos, int config, JointPos *joint_pos)
{
    const char * const methodName = "GetInverseKin";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

 	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);   
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iAi)", (xmlrpc_int32)type, arrayP, (xmlrpc_int32)config);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    for(i = 0; i < 6; i++)
    {
        xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1+i);
        dieIfFaultOccurred(&env);    
        xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&joint_pos->jPos[i]);
        dieIfFaultOccurred(&env);
    }
	
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	 
}

/**
 * @brief  逆运动学求解，参考指定关节位置求解
 * @param  [in] desc_pos 笛卡尔位姿
 * @param  [in] joint_pos_ref 参考关节位置
 * @param  [out] joint_pos 关节位置
 * @return  错误码
 */	
errno_t  FRRobot::GetInverseKinRef(DescPose *desc_pos, JointPos *joint_pos_ref, JointPos *joint_pos)
{
    const char * const methodName = "GetInverseKinRef";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP, *arrayP1;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

 	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);  

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos_ref->jPos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP1, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	} 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(AA)", arrayP, arrayP1);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    for(i = 0; i < 6; i++)
    {
        xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1+i);
        dieIfFaultOccurred(&env);    
        xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&joint_pos->jPos[i]);
        dieIfFaultOccurred(&env);
    }
	
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}

/**
 * @brief  逆运动学求解，参考指定关节位置判断是否有解
 * @param  [in] desc_pos 笛卡尔位姿
 * @param  [in] joint_pos_ref 参考关节位置
 * @param  [out] result 0-无解，1-有解
 * @return  错误码
 */	
errno_t  FRRobot::GetInverseKinHasSolution(int type, DescPose *desc_pos, JointPos *joint_pos_ref, uint8_t *result)
{
    const char * const methodName = "GetInverseKinHasSolution";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP, *arrayP1;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    const char *str;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

 	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);  

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos_ref->jPos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP1, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	} 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iAA)", (xmlrpc_int32)type,  arrayP, arrayP1);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_string(&env, strctP1, &str);
    dieIfFaultOccurred(&env);	
    // 判断False或True
    if(0 == strcmp(str, "False"))
    {
        *result = 0;
    }
    else if(0 == strcmp(str, "True"))
    {
        *result = 1;
    }
	
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	      
}

/**
 * @brief  正运动学求解
 * @param  [in] joint_pos 关节位置
 * @param  [out] desc_pos 笛卡尔位姿
 * @return  错误码
 */
errno_t  FRRobot::GetForwardKin(JointPos *joint_pos, DescPose *desc_pos)
{
    const char * const methodName = "GetForwardKin";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

 	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos->jPos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(A)", arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&desc_pos->tran.x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&desc_pos->tran.y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&desc_pos->tran.z);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 4);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP4, (xmlrpc_double*)&desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP5 = xmlrpc_array_get_item(&env, resultP, 5);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP5, (xmlrpc_double*)&desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP6 = xmlrpc_array_get_item(&env, resultP, 6);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP6, (xmlrpc_double*)&desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	
}
	
/**
 * @brief 获取当前关节转矩
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] torques 关节转矩
 * @return  错误码
 */
errno_t  FRRobot::GetJointTorques(uint8_t flag, float torques[6])
{
    int errcode = 0;
    int i;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        for(i = 0; i < 6; i++)
        {
            torques[i] = robot_state_pkg.jt_cur_tor[i];
        }       
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	
}
	
/**
 * @brief  获取当前负载的重量
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] weight 负载重量，单位kg
 * @return  错误码
 */
errno_t  FRRobot::GetTargetPayload(uint8_t flag, float *weight)
{
    const char * const methodName = "GetTargetPayload";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)flag);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
	dieIfFaultOccurred(&env);
	
	xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);    
    xmlrpc_double w;
    xmlrpc_read_double(&env, strctP1, &w);
	dieIfFaultOccurred(&env);	
    *weight = w;
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	 
}
	
/**
 * @brief  获取当前负载的质心
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] cog 负载质心，单位mm
 * @return  错误码
 */	
errno_t  FRRobot::GetTargetPayloadCog(uint8_t flag, DescTran *cog)
{
    const char * const methodName = "GetTargetPayloadCog";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)flag);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&cog->x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&cog->y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&cog->z);
    dieIfFaultOccurred(&env);		

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	 
}
	
/**
 * @brief  获取当前工具坐标系
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] desc_pos 工具坐标系位姿
 * @return  错误码
 */
errno_t  FRRobot::GetTCPOffset(uint8_t flag, DescPose *desc_pos)
{
    const char * const methodName = "GetTCPOffset";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)flag);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&desc_pos->tran.x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&desc_pos->tran.y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&desc_pos->tran.z);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 4);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP4, (xmlrpc_double*)&desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP5 = xmlrpc_array_get_item(&env, resultP, 5);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP5, (xmlrpc_double*)&desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP6 = xmlrpc_array_get_item(&env, resultP, 6);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP6, (xmlrpc_double*)&desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}
	
/**
 * @brief  获取当前工件坐标系
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] desc_pos 工件坐标系位姿
 * @return  错误码
 */	
errno_t  FRRobot::GetWObjOffset(uint8_t flag, DescPose *desc_pos)
{
    const char * const methodName = "GetWObjOffset";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)flag);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&desc_pos->tran.x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&desc_pos->tran.y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&desc_pos->tran.z);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 4);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP4, (xmlrpc_double*)&desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP5 = xmlrpc_array_get_item(&env, resultP, 5);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP5, (xmlrpc_double*)&desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP6 = xmlrpc_array_get_item(&env, resultP, 6);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP6, (xmlrpc_double*)&desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}
	
/**
 * @brief  获取关节软限位角度
 * @param  [in] flag 0-阻塞，1-非阻塞	 
 * @param  [out] negative  负限位角度，单位deg
 * @param  [out] positive  正限位角度，单位deg
 * @return  错误码
 */
errno_t  FRRobot::GetJointSoftLimitDeg(uint8_t flag, float negative[6], float positive[6])
{
    const char * const methodName = "GetJointSoftLimitDeg";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)flag);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    int m = 0, n = 0;
    for(i = 0; i < 12; i++)
    {
        xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1+i);
        dieIfFaultOccurred(&env); 
        if(i % 2 == 0)
        {
            xmlrpc_double neg;
            xmlrpc_read_double(&env, strctP1, &neg);
            negative[m] = neg;
            dieIfFaultOccurred(&env);	
            m +=1;
        }
        else if(i % 2 == 1)
        {
            xmlrpc_double pos;
            xmlrpc_read_double(&env, strctP1, &pos);
            positive[n] = pos;
            dieIfFaultOccurred(&env);	
            n += 1;
        }   

    }	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}
	
/**
 * @brief  获取系统时间
 * @param  [out] t_ms 单位ms
 * @return  错误码
 */
errno_t  FRRobot::GetSystemClock(float *t_ms)
{
    const char * const methodName = "GetSystemClock";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
	dieIfFaultOccurred(&env);
	
	xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);   
    xmlrpc_double t; 
    xmlrpc_read_double(&env, strctP1, &t);
    *t_ms = t;
	dieIfFaultOccurred(&env);	
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}
	
/**
 * @brief  获取机器人当前关节位置
 * @param  [out]  config  关节空间配置，范围[0~7]
 * @return  错误码
 */
errno_t  FRRobot::GetRobotCurJointsConfig(int *config)
{
    const char * const methodName = "GetRobotCurJointsConfig";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
	dieIfFaultOccurred(&env);
	
	xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP1, (xmlrpc_int32*)config);
	dieIfFaultOccurred(&env);	
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	       
}

/**
 * @brief  获取机器人当前速度
 * @param  [out]  vel  速度，单位mm/s
 * @return  错误码
 */	
errno_t  FRRobot::GetDefaultTransVel(float *vel)
{
    const char * const methodName = "GetDefaultTransVel";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
	dieIfFaultOccurred(&env);
	
	xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);    
    xmlrpc_double v;
    xmlrpc_read_double(&env, strctP1, &v);
    *vel = v;
	dieIfFaultOccurred(&env);	
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	 
}

/**
 * @brief  查询机器人运动是否完成
 * @param  [out]  state  0-未完成，1-完成
 * @return  错误码
 */	
errno_t  FRRobot::GetRobotMotionDone(uint8_t *state)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *state = robot_state_pkg.motion_done;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	    
}

/**
 * @brief  查询机器人错误码
 * @param  [out]  maincode  主错误码
 * @param  [out]  subcode   子错误码
 * @return  错误码
 */	
errno_t  FRRobot::GetRobotErrorCode(int *maincode, int *subcode)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *maincode = robot_state_pkg.main_code;
        *subcode  = robot_state_pkg.sub_code;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	    
}

/**
 * @brief  查询机器人示教管理点位数据
 * @param  [in]  name  点位名
 * @param  [out]  data   点位数据
 * @return  错误码
 */	
errno_t  FRRobot::GetRobotTeachingPoint(char name[64], float data[20])
{
    const char * const methodName = "GetRobotTeachingPoint";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(s)", name);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    int i;
    for(i = 0; i < 20; i++)
    {
        xmlrpc_double tmp_data = 0.0;
        xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1+i);
        dieIfFaultOccurred(&env);    
        xmlrpc_read_double(&env, strctP1, &tmp_data);
        dieIfFaultOccurred(&env);	
        data[i] = tmp_data;
    }
	
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
     
    return errcode;	   
}


/**
 * @brief  查询机器人运动队列缓存长度
 * @param  [out]  len  缓存长度
 * @return  错误码
 */	
errno_t  FRRobot::GetMotionQueueLength(int *len)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *len = robot_state_pkg.mc_queue_len;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	  
}

/**
 * @brief  设置轨迹记录参数
 * @param  [in] type  记录数据类型，1-关节位置
 * @param  [in] name  轨迹文件名
 * @param  [in] period_ms  数据采样周期，固定值2ms或4ms或8ms
 * @param  [in] di_choose  DI选择,bit0~bit7对应控制箱DI0~DI7，bit8~bit9对应末端DI0~DI1，0-不选择，1-选择
 * @param  [in] do_choose  DO选择,bit0~bit7对应控制箱DO0~DO7，bit8~bit9对应末端DO0~DO1，0-不选择，1-选择
 * @return  错误码
 */
errno_t  FRRobot::SetTPDParam(int type, char name[30], int period_ms, uint16_t di_choose, uint16_t do_choose)
{
    const char * const methodName = "SetTPDParam";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(isiii)", (xmlrpc_int32)type, name, (xmlrpc_int32)period_ms, (xmlrpc_int32)di_choose, (xmlrpc_int32)do_choose);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }     
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	      
}
	
/**
 * @brief  开始轨迹记录
 * @param  [in] type  记录数据类型，1-关节位置
 * @param  [in] name  轨迹文件名
 * @param  [in] period_ms  数据采样周期，固定值2ms或4ms或8ms
 * @param  [in] di_choose  DI选择,bit0~bit7对应控制箱DI0~DI7，bit8~bit9对应末端DI0~DI1，0-不选择，1-选择
 * @param  [in] do_choose  DO选择,bit0~bit7对应控制箱DO0~DO7，bit8~bit9对应末端DO0~DO1，0-不选择，1-选择
 * @return  错误码
 */
errno_t  FRRobot::SetTPDStart(int type, char name[30], int period_ms, uint16_t di_choose, uint16_t do_choose)
{
    const char * const methodName = "SetTPDStart";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }   
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(isiii)", (xmlrpc_int32)type, name, (xmlrpc_int32)period_ms, (xmlrpc_int32)di_choose, (xmlrpc_int32)do_choose);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	         
}
	
/**
 * @brief  停止轨迹记录
 * @return  错误码
 */
errno_t  FRRobot::SetWebTPDStop()
{
    const char * const methodName = "SetWebTPDStop";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}
	
/**
 * @brief  删除轨迹记录
 * @param  [in] name  轨迹文件名
 * @return  错误码
 */	
errno_t  FRRobot::SetTPDDelete(char name[30])
{
    const char * const methodName = "SetTPDDelete";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(s)", name);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}
	
/**
 * @brief  轨迹预加载
 * @param  [in] name  轨迹文件名
 * @return  错误码
 */		
errno_t  FRRobot::LoadTPD(char name[30])
{
    const char * const methodName = "LoadTPD";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(s)", name);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}

/**
 * @brief  获取轨迹起始位姿
 * @param  [in] name 轨迹文件名
 * @return  错误码
 */		
errno_t  FRRobot::GetTPDStartPose(char name[30], DescPose *desc_pose)
{
    const char * const methodName = "GetTPDStartPose";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(s)", name);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&desc_pose->tran.x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&desc_pose->tran.y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&desc_pose->tran.z);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 4);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP4, (xmlrpc_double*)&desc_pose->rpy.rx);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP5 = xmlrpc_array_get_item(&env, resultP, 5);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP5, (xmlrpc_double*)&desc_pose->rpy.ry);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP6 = xmlrpc_array_get_item(&env, resultP, 6);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP6, (xmlrpc_double*)&desc_pose->rpy.rz);
    dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}
	
/**
 * @brief  轨迹复现
 * @param  [in] name  轨迹文件名
 * @param  [in] blend 0-不平滑，1-平滑
 * @param  [in] ovl  速度缩放百分比，范围[0~100]
 * @return  错误码
 */
errno_t  FRRobot::MoveTPD(char name[30], uint8_t blend, float ovl)
{
    const char * const methodName = "MoveTPD";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(sid)", name, (xmlrpc_int32)blend, (xmlrpc_double)ovl);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	         
}

/**
 * @brief  轨迹预处理
 * @param  [in] name  轨迹文件名
 * @param  [in] ovl 速度缩放百分比，范围[0~100]
 * @param  [in] opt 1-控制点，默认为1
 * @return  错误码
 */		
errno_t  FRRobot::LoadTrajectoryJ(char name[30], float ovl, int opt)
{
    const char * const methodName = "LoadTrajectoryJ";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(sdi)", name,  (xmlrpc_double)ovl, (xmlrpc_int32)opt);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}

/**
 * @brief  轨迹复现
 * @return  错误码
 */		
errno_t  FRRobot::MoveTrajectoryJ()
{
    const char * const methodName = "MoveTrajectoryJ";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}

/**
 * @brief  获取轨迹起始位姿
 * @param  [in] name 轨迹文件名
 * @return  错误码
 */		
errno_t  FRRobot::GetTrajectoryStartPose(char name[30], DescPose *desc_pose)
{
    const char * const methodName = "GetTrajectoryStartPose";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(s)", name);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&desc_pose->tran.x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&desc_pose->tran.y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&desc_pose->tran.z);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 4);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP4, (xmlrpc_double*)&desc_pose->rpy.rx);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP5 = xmlrpc_array_get_item(&env, resultP, 5);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP5, (xmlrpc_double*)&desc_pose->rpy.ry);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP6 = xmlrpc_array_get_item(&env, resultP, 6);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP6, (xmlrpc_double*)&desc_pose->rpy.rz);
    dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}

/**
 * @brief  获取轨迹点编号
 * @return  错误码
 */		
errno_t  FRRobot::GetTrajectoryPointNum(int *pnum)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *pnum = robot_state_pkg.trajectory_pnum;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	  
}

/**
 * @brief  设置轨迹运行中的速度
 * @param  [in] ovl 速度百分比
 * @return  错误码
 */		
errno_t  FRRobot::SetTrajectoryJSpeed(float ovl)
{
    const char * const methodName = "SetTrajectoryJSpeed";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(d)", (xmlrpc_double)ovl);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}

/**
 * @brief  设置轨迹运行中的力和扭矩
 * @param  [in] ft 三个方向的力和扭矩，单位N和Nm
 * @return  错误码
 */		
errno_t  FRRobot::SetTrajectoryJForceTorque(ForceTorque *ft)
{
    const char * const methodName = "SetTrajectoryJForceTorque";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

 	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, ft->fx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, ft->fy);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, ft->fz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, ft->tx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, ft->ty);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, ft->tz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);  

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(A)", arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
    xmlrpc_read_int(&env, resultP, &errcode);
    errcode = dieIfFaultOccurred(&env);  
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  
	
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}

/**
 * @brief  设置轨迹运行中的沿x方向的力
 * @param  [in] fx 沿x方向的力，单位N
 * @return  错误码
 */		
errno_t  FRRobot::SetTrajectoryJForceFx(double fx)
{
    const char * const methodName = "SetTrajectoryJForceFx";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(d)", fx);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	      
}

/**
 * @brief  设置轨迹运行中的沿y方向的力
 * @param  [in] fy 沿y方向的力，单位N
 * @return  错误码
 */		
errno_t  FRRobot::SetTrajectoryJForceFy(double fy)
{
    const char * const methodName = "SetTrajectoryJForceFy";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(d)", fy);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	      
}

/**
 * @brief  设置轨迹运行中的沿z方向的力
 * @param  [in] fz 沿x方向的力，单位N
 * @return  错误码
 */		
errno_t  FRRobot::SetTrajectoryJForceFz(double fz)
{
    const char * const methodName = "SetTrajectoryJForceFz";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(d)", fz);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }  
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}

/**
 * @brief  设置轨迹运行中的绕x轴的扭矩
 * @param  [in] tx 绕x轴的扭矩，单位Nm
 * @return  错误码
 */		
errno_t  FRRobot::SetTrajectoryJTorqueTx(double tx)
{
    const char * const methodName = "SetTrajectoryJTorqueTx";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(d)", tx);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	       
}

/**
 * @brief  设置轨迹运行中的绕x轴的扭矩
 * @param  [in] ty 绕y轴的扭矩，单位Nm
 * @return  错误码
 */		
errno_t  FRRobot::SetTrajectoryJTorqueTy(double ty)
{
    const char * const methodName = "SetTrajectoryJTorqueTy";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(d)", ty);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	 
}

/**
 * @brief  设置轨迹运行中的绕x轴的扭矩
 * @param  [in] tz 绕z轴的扭矩，单位Nm
 * @return  错误码
 */		
errno_t  FRRobot::SetTrajectoryJTorqueTz(double tz)
{
    const char * const methodName = "SetTrajectoryJTorqueTz";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(d)", tz);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}

	
/**
 * @brief  设置开机自动加载默认的作业程序
 * @param  [in] flag  0-开机不自动加载默认程序，1-开机自动加载默认程序
 * @param  [in] program_name 作业程序名及路径，如"/fruser/movej.lua"，其中"/fruser/"为固定路径
 * @return  错误码
 */
errno_t  FRRobot::LoadDefaultProgConfig(uint8_t flag, char program_name[64])
{
    const char * const methodName = "LoadDefaultProgConfig";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(is)", (xmlrpc_int32)flag, program_name);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	         
}
	
/**
 * @brief  加载指定的作业程序
 * @param  [in] program_name 作业程序名及路径，如"/fruser/movej.lua"，其中"/fruser/"为固定路径
 * @return  错误码
 */
errno_t  FRRobot::ProgramLoad(char program_name[64])
{
    const char * const methodName = "ProgramLoad";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(s)", program_name);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	         
}
	
/**
 * @brief  获取已加载的作业程序名
 * @param  [out] program_name 作业程序名及路径，如"/fruser/movej.lua"，其中"/fruser/"为固定路径
 * @return  错误码
 */
errno_t  FRRobot::GetLoadedProgram(char program_name[64])
{
    const char * const methodName = "GetLoadedProgram";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    const char *str;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
	dieIfFaultOccurred(&env);
	
	xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_string(&env, strctP1, &str);
	dieIfFaultOccurred(&env);
	strncpy(program_name, str, strlen(str));	
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;		    
}
	
/**
 * @brief  获取当前机器人作业程序执行的行号
 * @param  [out] line  行号
 * @return  错误码
 */	
errno_t  FRRobot::GetCurrentLine(int *line)
{
    const char * const methodName = "GetCurrentLine";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
	dieIfFaultOccurred(&env);
	
	xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP1, (xmlrpc_int32*)line);
	dieIfFaultOccurred(&env);	
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;		
}
	
/**
 * @brief  运行当前加载的作业程序
 * @return  错误码
 */
errno_t  FRRobot::ProgramRun()
{
    const char * const methodName = "ProgramRun";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}
	
/**
 * @brief  暂停当前运行的作业程序
 * @return  错误码
 */ 
errno_t  FRRobot::ProgramPause()
{
    const char * const methodName = "ProgramPause";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	      
}

/**
 * @brief  恢复当前暂停的作业程序
 * @return  错误码
 */ 
errno_t  FRRobot::ProgramResume()
{
    const char * const methodName = "ProgramResume";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	      
}	
	
/**
 * @brief  终止当前运行的作业程序
 * @return  错误码
 */ 
errno_t  FRRobot::ProgramStop()
{
    const char * const methodName = "ProgramStop";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}		
	
/**
 * @brief  获取机器人作业程序执行状态
 * @param  [out]  state 1-程序停止或无程序运行，2-程序运行中，3-程序暂停
 * @return  错误码
 */
errno_t  FRRobot::GetProgramState(uint8_t *state)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *state = robot_state_pkg.robot_state;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;		    
}

/**
 * @brief  配置夹爪
 * @param  [in] company  夹爪厂商，待定
 * @param  [in] device  设备号，暂不使用，默认为0
 * @param  [in] softvesion  软件版本号，暂不使用，默认为0
 * @param  [in] bus 设备挂在末端总线位置，暂不使用，默认为0
 * @return  错误码
 */
errno_t  FRRobot::SetGripperConfig(int company, int device, int softvesion, int bus)
{
    const char * const methodName = "SetGripperConfig";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iiii)", (xmlrpc_int32)company, (xmlrpc_int32)device, (xmlrpc_int32)softvesion, (xmlrpc_int32)bus);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();  

    return errcode;  
}
	
/**
 * @brief  获取夹爪配置
 * @param  [in] company  夹爪厂商，待定
 * @param  [in] device  设备号，暂不使用，默认为0
 * @param  [in] softvesion  软件版本号，暂不使用，默认为0
 * @param  [in] bus 设备挂在末端总线位置，暂不使用，默认为0
 * @return  错误码
 */
errno_t  FRRobot::GetGripperConfig(int *company, int *device, int *softvesion, int *bus)
{
    const char * const methodName = "GetGripperConfig";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
	dieIfFaultOccurred(&env);
	
	xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP1, (xmlrpc_int32*)company);
	dieIfFaultOccurred(&env);	

	xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP2, (xmlrpc_int32*)device);
	dieIfFaultOccurred(&env);

 	xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP3, (xmlrpc_int32*)softvesion);
	dieIfFaultOccurred(&env);	   

	xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 4);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP4, (xmlrpc_int32*)bus);
	dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}

/**
 * @brief  激活夹爪
 * @param  [in] index  夹爪编号
 * @param  [in] act  0-复位，1-激活
 * @return  错误码
 */
errno_t  FRRobot::ActGripper(int index, uint8_t act)
{
    const char * const methodName = "ActGripper";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(ii)", (xmlrpc_int32)index, (xmlrpc_int32)act);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();   

    return errcode;   
}

/**
 * @brief  控制夹爪
 * @param  [in] index  夹爪编号
 * @param  [in] pos  位置百分比，范围[0~100]
 * @param  [in] vel  速度百分比，范围[0~100]
 * @param  [in] force  力矩百分比，范围[0~100]
 * @param  [in] max_time  最大等待时间，范围[0~30000]，单位ms
 * @param  [in] block  0-阻塞，1-非阻塞
 * @return  错误码
 */
errno_t  FRRobot::MoveGripper(int index, int pos, int vel, int force, int max_time, uint8_t block)
{
    const char * const methodName = "MoveGripper";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iiiiii)", (xmlrpc_int32)index, (xmlrpc_int32)pos, (xmlrpc_int32)vel, (xmlrpc_int32)force, (xmlrpc_int32)max_time, (xmlrpc_int32)block);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();    

    return errcode;     
}

/**
 * @brief  获取夹爪运动状态
 * @param  [out] fault  0-无错误，1-有错误
 * @param  [out] status  0-运动未完成，1-运动完成
 * @return  错误码
 */
errno_t  FRRobot::GetGripperMotionDone(uint16_t *fault, uint8_t *status)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *fault  = robot_state_pkg.gripper_fault;
        *status = robot_state_pkg.gripper_motiondone;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	    
}

/**
 * @brief  获取夹爪激活状态
 * @param  [out] fault  0-无错误，1-有错误
 * @param  [out] status  bit0~bit15对应夹爪编号0~15，bit=0为未激活，bit=1为激活
 * @return  错误码
 */
errno_t  FRRobot::GetGripperActivateStatus(uint16_t *fault, uint16_t *status)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *fault  = robot_state_pkg.gripper_fault;
        *status = robot_state_pkg.gripper_active;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	   
}

/**
 * @brief  获取夹爪位置
 * @param  [out] fault  0-无错误，1-有错误
 * @param  [out] position  位置百分比，范围0~100%
 * @return  错误码
 */
errno_t  FRRobot::GetGripperCurPosition(uint16_t *fault, uint8_t *position)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *fault  = robot_state_pkg.gripper_fault;
        *position = robot_state_pkg.gripper_position;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	       
}

/**
 * @brief  获取夹爪速度
 * @param  [out] fault  0-无错误，1-有错误
 * @param  [out] speed  速度百分比，范围0~100%
 * @return  错误码
 */
errno_t  FRRobot::GetGripperCurSpeed(uint16_t *fault, int8_t *speed)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *fault  = robot_state_pkg.gripper_fault;
        *speed = robot_state_pkg.gripper_speed;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	       
}

/**
 * @brief  获取夹爪电流
 * @param  [out] fault  0-无错误，1-有错误
 * @param  [out] current  电流百分比，范围0~100%
 * @return  错误码
 */
errno_t  FRRobot::GetGripperCurCurrent(uint16_t *fault, int8_t *current)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *fault  = robot_state_pkg.gripper_fault;
        *current = robot_state_pkg.gripper_current;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	       
}

/**
 * @brief  获取夹爪电压
 * @param  [out] fault  0-无错误，1-有错误
 * @param  [out] voltage  电压,单位0.1V
 * @return  错误码
 */
errno_t  FRRobot::GetGripperVoltage(uint16_t *fault, int *voltage)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *fault  = robot_state_pkg.gripper_fault;
        *voltage = robot_state_pkg.gripper_voltage;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	   
}

/**
 * @brief  获取夹爪温度
 * @param  [out] fault  0-无错误，1-有错误
 * @param  [out] temp  温度，单位℃
 * @return  错误码
 */
errno_t  FRRobot::GetGripperTemp(uint16_t *fault, int *temp)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *fault  = robot_state_pkg.gripper_fault;
        *temp = robot_state_pkg.gripper_temp;
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;    
}

/**
 * @brief  计算预抓取点-视觉
 * @param  [in] desc_pos  抓取点笛卡尔位姿
 * @param  [in] zlength   z轴偏移量
 * @param  [in] zangle    绕z轴旋转偏移量
 * @return  错误码 
 */
errno_t  FRRobot::ComputePrePick(DescPose *desc_pos, double zlength, double zangle, DescPose *pre_pos)
{
    const char * const methodName = "ComputePrePick";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP1;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(Add)",arrayP1, zlength, zangle);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&pre_pos->tran.x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&pre_pos->tran.y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&pre_pos->tran.z);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 4);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP4, (xmlrpc_double*)&pre_pos->rpy.rx);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP5 = xmlrpc_array_get_item(&env, resultP, 5);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP5, (xmlrpc_double*)&pre_pos->rpy.ry);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP6 = xmlrpc_array_get_item(&env, resultP, 6);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP6, (xmlrpc_double*)&pre_pos->rpy.rz);
    dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}

/**
 * @brief  计算撤退点-视觉
 * @param  [in] desc_pos  抓取点笛卡尔位姿
 * @param  [in] zlength   z轴偏移量
 * @param  [in] zangle    绕z轴旋转偏移量
 * @return  错误码 
 */
errno_t  FRRobot::ComputePostPick(DescPose *desc_pos, double zlength, double zangle, DescPose *post_pos)
{
    const char * const methodName = "ComputePostPick";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP1;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, desc_pos->tran.x);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, desc_pos->tran.y);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, desc_pos->tran.z);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, desc_pos->rpy.rx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, desc_pos->rpy.ry);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, desc_pos->rpy.rz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP1, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(Add)",arrayP1, zlength, zangle);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 
    
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    } 

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&post_pos->tran.x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&post_pos->tran.y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&post_pos->tran.z);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 4);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP4, (xmlrpc_double*)&post_pos->rpy.rx);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP5 = xmlrpc_array_get_item(&env, resultP, 5);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP5, (xmlrpc_double*)&post_pos->rpy.ry);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP6 = xmlrpc_array_get_item(&env, resultP, 6);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP6, (xmlrpc_double*)&post_pos->rpy.rz);
    dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}
	
/**
 * @brief  配置力传感器
 * @param  [in] company  力传感器厂商，17-坤维科技
 * @param  [in] device  设备号，暂不使用，默认为0
 * @param  [in] softvesion  软件版本号，暂不使用，默认为0
 * @param  [in] bus 设备挂在末端总线位置，暂不使用，默认为0
 * @return  错误码
 */
errno_t  FRRobot::FT_SetConfig(int company, int device, int softvesion, int bus)
{
    const char * const methodName = "FT_SetConfig";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();
        return errcode;
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iiii)", (xmlrpc_int32)company, (xmlrpc_int32)device, (xmlrpc_int32)softvesion, (xmlrpc_int32)bus);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();
        return errcode;
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();
        return errcode;
    }

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();

    return errcode;     
}

/**
 * @brief  获取力传感器配置
 * @param  [in] company  力传感器厂商，待定
 * @param  [in] device  设备号，暂不使用，默认为0
 * @param  [in] softvesion  软件版本号，暂不使用，默认为0
 * @param  [in] bus 设备挂在末端总线位置，暂不使用，默认为0
 * @return  错误码
 */
errno_t  FRRobot::FT_GetConfig(int *company, int *device, int *softvesion, int *bus)
{
    const char * const methodName = "FT_GetConfig";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();
        return errcode;
    }

	xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
	dieIfFaultOccurred(&env);

    xmlrpc_read_int(&env, strctP0, &errcode);
	dieIfFaultOccurred(&env);

	xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);   
   
    xmlrpc_read_int(&env, strctP1, (xmlrpc_int32*)company);
	dieIfFaultOccurred(&env);	 

	xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);     

    xmlrpc_read_int(&env, strctP2, (xmlrpc_int32*)device);
	dieIfFaultOccurred(&env);  

 	xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);    
  
    xmlrpc_read_int(&env, strctP3, (xmlrpc_int32*)softvesion);
	dieIfFaultOccurred(&env);	   

	xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);    
     
    xmlrpc_read_int(&env, strctP4, (xmlrpc_int32*)bus);
	dieIfFaultOccurred(&env);	  

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}

/**
 * @brief  力传感器激活
 * @param  [in] act  0-复位，1-激活
 * @return  错误码
 */
errno_t  FRRobot::FT_Activate(uint8_t act)
{
    const char * const methodName = "FT_Activate";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)act);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();    

    return errcode;    
}
	
/**
 * @brief  力传感器校零
 * @param  [in] act  0-去除零点，1-零点矫正
 * @return  错误码
 */
errno_t  FRRobot::FT_SetZero(uint8_t act)
{
    const char * const methodName = "FT_SetZero";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)act);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();    

    return errcode;     
}

/**
 * @brief  设置力传感器参考坐标系
 * @param  [in] ref  0-工具坐标系，1-基坐标系
 * @return  错误码
 */
errno_t  FRRobot::FT_SetRCS(uint8_t ref)
{
    const char * const methodName = "FT_SetRCS";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)ref);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup(); 

    return errcode; 
}
	
/**
 * @brief  负载重量辨识记录
 * @param  [in] id  传感器坐标系编号，范围[1~14]
 * @return  错误码
 */
errno_t  FRRobot::FT_PdIdenRecord(int id)
{
    const char * const methodName = "FT_PdIdenRecord";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)id);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();     

    return errcode; 
}
	
/**
 * @brief  负载重量辨识计算
 * @param  [out] weight  负载重量，单位kg
 * @return  错误码
 */	
errno_t  FRRobot::FT_PdIdenCompute(float *weight)
{
    const char * const methodName = "FT_PdIdenCompute";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
	xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
	dieIfFaultOccurred(&env);
	
	xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);    
    xmlrpc_double w;
    xmlrpc_read_double(&env, strctP1, &w);
    *weight = w;
	dieIfFaultOccurred(&env);	
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}
	
/**
 * @brief  负载质心辨识记录
 * @param  [in] id  传感器坐标系编号，范围[1~14]
 * @param  [in] index 点编号，范围[1~3]
 * @return  错误码
 */
errno_t  FRRobot::FT_PdCogIdenRecord(int id, int index)
{
    const char * const methodName = "FT_PdCogIdenRecord";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(ii)", (xmlrpc_int32)id, (xmlrpc_int32)index);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();     

    return errcode;    
}
	
/**
 * @brief  负载质心辨识计算
 * @param  [out] cog  负载质心，单位mm
 * @return  错误码
 */	
errno_t  FRRobot::FT_PdCogIdenCompute(DescTran *cog)
{
    const char * const methodName = "FT_PdCogIdenCompute";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&cog->x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&cog->y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&cog->z);
    dieIfFaultOccurred(&env);		

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}	

/**
 * @brief  获取参考坐标系下力/扭矩数据
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] ft  力/扭矩，fx,fy,fz,tx,ty,tz
 * @return  错误码
 */	
errno_t  FRRobot::FT_GetForceTorqueRCS(uint8_t flag, ForceTorque *ft)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        ft->fx = robot_state_pkg.ft_sensor_data[0];
        ft->fy = robot_state_pkg.ft_sensor_data[1];
        ft->fz = robot_state_pkg.ft_sensor_data[2];
        ft->tx = robot_state_pkg.ft_sensor_data[3];
        ft->ty = robot_state_pkg.ft_sensor_data[4];
        ft->tz = robot_state_pkg.ft_sensor_data[5];        
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	     
}

/**
 * @brief  获取力传感器原始力/扭矩数据
 * @param  [in] flag 0-阻塞，1-非阻塞
 * @param  [out] ft  力/扭矩，fx,fy,fz,tx,ty,tz
 * @return  错误码
 */	
errno_t  FRRobot::FT_GetForceTorqueOrigin(uint8_t flag, ForceTorque *ft)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        ft->fx = robot_state_pkg.ft_sensor_raw_data[0];
        ft->fy = robot_state_pkg.ft_sensor_raw_data[1];
        ft->fz = robot_state_pkg.ft_sensor_raw_data[2];
        ft->tx = robot_state_pkg.ft_sensor_raw_data[3];
        ft->ty = robot_state_pkg.ft_sensor_raw_data[4];
        ft->tz = robot_state_pkg.ft_sensor_raw_data[5];
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	  
}

/**
 * @brief  碰撞守护
 * @param  [in] flag 0-关闭碰撞守护，1-开启碰撞守护
 * @param  [in] sensor_id 力传感器编号
 * @param  [in] select  选择六个自由度是否检测碰撞，0-不检测，1-检测
 * @param  [in] ft  碰撞力/扭矩，fx,fy,fz,tx,ty,tz
 * @param  [in] max_threshold 最大阈值
 * @param  [in] min_threshold 最小阈值
 * @note   力/扭矩检测范围：(ft-min_threshold, ft+max_threshold)
 * @return  错误码
 */	
errno_t  FRRobot::FT_Guard(uint8_t flag, int sensor_id, uint8_t select[6], ForceTorque *ft, float max_threshold[6], float min_threshold[6])
{
    const char * const methodName = "FT_Guard";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP1, *arrayP2, *arrayP3, *arrayP4;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_int_new(&env, select[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP1, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}    

 	arrayP2 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, ft->fx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, ft->fy);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, ft->fz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, ft->tx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, ft->ty);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, ft->tz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);  

	arrayP3 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, max_threshold[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP3, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}  

	arrayP4= xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, min_threshold[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP4, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	} 
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iiAAAA)", (xmlrpc_int32)flag, (xmlrpc_int32)sensor_id, arrayP1, arrayP2, arrayP3, arrayP4);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
    xmlrpc_read_int(&env, resultP, &errcode);
    errcode = dieIfFaultOccurred(&env);    
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}
	
/**
 * @brief  恒力控制
 * @param  [in] flag 0-关闭恒力控制，1-开启恒力控制
 * @param  [in] sensor_id 力传感器编号
 * @param  [in] select  选择六个自由度是否检测碰撞，0-不检测，1-检测
 * @param  [in] ft  碰撞力/扭矩，fx,fy,fz,tx,ty,tz
 * @param  [in] ft_pid 力pid参数，力矩pid参数
 * @param  [in] adj_sign 自适应启停控制，0-关闭，1-开启
 * @param  [in] ILC_sign ILC启停控制， 0-停止，1-训练，2-实操
 * @param  [in] 最大调整距离，单位mm
 * @param  [in] 最大调整角度，单位deg
 * @return  错误码
 */	
errno_t  FRRobot::FT_Control(uint8_t flag, int sensor_id, uint8_t select[6], ForceTorque *ft, float ft_pid[6], uint8_t adj_sign, uint8_t ILC_sign, float max_dis, float max_ang)
{
    const char * const methodName = "FT_Control";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP1, *arrayP2, *arrayP3;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_int_new(&env, select[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP1, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}    

 	arrayP2 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);
	xmlrpc_value *dP1 = xmlrpc_double_new(&env, ft->fx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP1);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP1);
	xmlrpc_value *dP2 = xmlrpc_double_new(&env, ft->fy);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP2);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP2);
 	xmlrpc_value *dP3 = xmlrpc_double_new(&env, ft->fz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP3);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP3);   
	xmlrpc_value *dP4 = xmlrpc_double_new(&env, ft->tx);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP4);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP4);
	xmlrpc_value *dP5 = xmlrpc_double_new(&env, ft->ty);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP5);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP5);
	xmlrpc_value *dP6 = xmlrpc_double_new(&env, ft->tz);
    dieIfFaultOccurred(&env);
    xmlrpc_array_append_item(&env, arrayP2, dP6);
    dieIfFaultOccurred(&env);
    xmlrpc_DECREF(dP6);  

	arrayP3 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, ft_pid[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP3, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}    
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iiAAAiidd)", (xmlrpc_int32)flag, (xmlrpc_int32)sensor_id, arrayP1, arrayP2, arrayP3, (xmlrpc_int32)adj_sign, (xmlrpc_int32)ILC_sign, (xmlrpc_double)max_dis, (xmlrpc_double)max_ang);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	 
    xmlrpc_read_int(&env, resultP, &errcode);
    errcode = dieIfFaultOccurred(&env);    
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	       
}

/**
 * @brief  螺旋线探索
 * @param  [in] rcs 参考坐标系，0-工具坐标系，1-基坐标系
 * @param  [in] dr 每圈半径进给量
 * @param  [in] ft 力/扭矩阈值，fx,fy,fz,tx,ty,tz，范围[0~100]
 * @param  [in] max_t_ms 最大探索时间，单位ms
 * @param  [in] max_vel 最大线速度，单位mm/s
 * @return  错误码
 */	
errno_t  FRRobot::FT_SpiralSearch(int rcs, float dr, float ft, float max_t_ms, float max_vel)
{
    const char * const methodName = "FT_SpiralSearch";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);  
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(idddd)", (xmlrpc_int32)rcs, (xmlrpc_double)dr, (xmlrpc_double)ft, (xmlrpc_double)max_t_ms, (xmlrpc_double)max_vel);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
    xmlrpc_read_int(&env, resultP, &errcode);
    errcode = dieIfFaultOccurred(&env);  
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}
	
/**
 * @brief  旋转插入
 * @param  [in] rcs 参考坐标系，0-工具坐标系，1-基坐标系
 * @param  [in] angVelRot 旋转角速度，单位deg/s
 * @param  [in] ft  力/扭矩阈值，fx,fy,fz,tx,ty,tz，范围[0~100]
 * @param  [in] max_angle 最大旋转角度，单位deg
 * @param  [in] orn 力/扭矩方向，1-沿z轴方向，2-绕z轴方向
 * @param  [in] max_angAcc 最大旋转加速度，单位deg/s^2，暂不使用，默认为0
 * @param  [in] rotorn  旋转方向，1-顺时针，2-逆时针
 * @return  错误码
 */	
errno_t  FRRobot::FT_RotInsertion(int rcs, float angVelRot, float ft, float max_angle, uint8_t orn, float max_angAcc, uint8_t rotorn)
{
    const char * const methodName = "FT_RotInsertion";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);  
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(idddidi)", (xmlrpc_int32)rcs, (xmlrpc_double)angVelRot, (xmlrpc_double)ft, (xmlrpc_double)max_angle, (xmlrpc_int32)orn, (xmlrpc_double)max_angAcc, (xmlrpc_int32)rotorn);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
    xmlrpc_read_int(&env, resultP, &errcode);
    errcode = dieIfFaultOccurred(&env);     
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}
	
/**
 * @brief  直线插入
 * @param  [in] rcs 参考坐标系，0-工具坐标系，1-基坐标系
 * @param  [in] ft  力/扭矩阈值，fx,fy,fz,tx,ty,tz，范围[0~100]
 * @param  [in] lin_v 直线速度，单位mm/s
 * @param  [in] lin_a 直线加速度，单位mm/s^2，暂不使用
 * @param  [in] max_dis 最大插入距离，单位mm
 * @param  [in] linorn  插入方向，0-负方向，1-正方向
 * @return  错误码
 */	
errno_t  FRRobot::FT_LinInsertion(int rcs, float ft, float lin_v, float lin_a, float max_dis, uint8_t linorn)
{
    const char * const methodName = "FT_LinInsertion";
    
    xmlrpc_env env;
    xmlrpc_value *arrayP;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env); 
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iddddi)", (xmlrpc_int32)rcs, (xmlrpc_double)ft, (xmlrpc_double)lin_v, (xmlrpc_double)lin_a, (xmlrpc_double)max_dis, (xmlrpc_int32)linorn);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
    xmlrpc_read_int(&env, resultP, &errcode);
    errcode = dieIfFaultOccurred(&env);    
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	     
}

/**
 * @brief  表面定位
 * @param  [in] rcs 参考坐标系，0-工具坐标系，1-基坐标系
 * @param  [in] dir  移动方向，1-正方向，2-负方向 
 * @param  [in] axis 移动轴，1-x轴，2-y轴，3-z轴
 * @param  [in] lin_v 探索直线速度，单位mm/s
 * @param  [in] lin_a 探索直线加速度，单位mm/s^2，暂不使用，默认为0
 * @param  [in] max_dis 最大探索距离，单位mm
 * @param  [in] ft  动作终止力/扭矩阈值，fx,fy,fz,tx,ty,tz	 
 * @return  错误码
 */	
errno_t  FRRobot::FT_FindSurface(int rcs, uint8_t dir, uint8_t axis, float lin_v, float lin_a, float max_dis, float ft)
{
    const char * const methodName = "FT_FindSurface";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);  
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(iiidddd)", (xmlrpc_int32)rcs, (xmlrpc_int32)dir, (xmlrpc_int32)axis, (xmlrpc_double)lin_v, (xmlrpc_double)lin_a, (xmlrpc_double)max_dis, (xmlrpc_double)ft);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }

    xmlrpc_read_int(&env, resultP, &errcode);
    errcode = dieIfFaultOccurred(&env); 
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	      
}
	
/**
 * @brief  计算中间平面位置开始
 * @return  错误码
 */	
errno_t  FRRobot::FT_CalCenterStart()
{
    const char * const methodName = "FT_CalCenterStart";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();   

    return errcode; 
}
	
/**
 * @brief  计算中间平面位置结束
 * @param  [out] pos 中间平面位姿
 * @return  错误码
 */		
errno_t  FRRobot::FT_CalCenterEnd(DescPose *pos)
{
    const char * const methodName = "FT_CalCenterEnd";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&pos->tran.x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&pos->tran.y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&pos->tran.z);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP4 = xmlrpc_array_get_item(&env, resultP, 4);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP4, (xmlrpc_double*)&pos->rpy.rx);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP5 = xmlrpc_array_get_item(&env, resultP, 5);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP5, (xmlrpc_double*)&pos->rpy.ry);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP6 = xmlrpc_array_get_item(&env, resultP, 6);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP6, (xmlrpc_double*)&pos->rpy.rz);
    dieIfFaultOccurred(&env);	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	  
}
	
/**
 * @brief  柔顺控制开启
 * @param  [in] p 位置调节系数或柔顺系数
 * @param  [in] force 柔顺开启力阈值，单位N
 * @return  错误码
 */	
errno_t  FRRobot::FT_ComplianceStart(float p, float force)
{
    const char * const methodName = "FT_ComplianceStart";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(dd)", (xmlrpc_double)p, (xmlrpc_double)force);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();  

    return errcode; 
}
	
/**
 * @brief  柔顺控制关闭
 * @return  错误码
 */	
errno_t  FRRobot::FT_ComplianceStop()
{
    const char * const methodName = "FT_ComplianceStop";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();       

    return errcode;  
}

/**
 * @brief 负载辨识初始化
 * @return 错误码
 */
errno_t FRRobot::LoadIdentifyDynFilterInit()
{
    const char * const methodName = "LoadIdentifyDynFilterInit";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();       

    return errcode;  
}

/**
 * @brief 负载辨识初始化
 * @return 错误码
 */
errno_t FRRobot::LoadIdentifyDynVarInit()
{
    const char * const methodName = "LoadIdentifyDynVarInit";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();       

    return errcode;      
}

/**
 * @brief 负载辨识主程序
 * @param [in] joint_torque 关节扭矩
 * @param [in] joint_pos 关节位置
 * @param [in] t 采样周期
 * @return 错误码
 */
errno_t FRRobot::LoadIdentifyMain(double joint_torque[6], double joint_pos[6], double t)
{
    const char * const methodName = "LoadIdentifyMain";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP, *arrayP1;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_torque[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

	arrayP1 = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 6; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, joint_pos[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP1, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(AAd)",arrayP, arrayP1, t);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;		
}


/**
 * @brief 获取负载辨识结果
 * @param [in] gain  
 * @param [out] weight 负载重量
 * @param [out] cog 负载质心
 * @return 错误码
 */
errno_t FRRobot::LoadIdentifyGetResult(double gain[12], double *weight, DescTran *cog)
{
    const char * const methodName = "LoadIdentifyGetResult";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 20; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, gain[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(A)",arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
    dieIfFaultOccurred(&env);    

	xmlrpc_value * strctP = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);    
    xmlrpc_double w;
    xmlrpc_read_double(&env, strctP, &w);
    *weight = w;
	dieIfFaultOccurred(&env);	

    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 2);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP1, (xmlrpc_double*)&cog->x);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP2 = xmlrpc_array_get_item(&env, resultP, 3);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP2, (xmlrpc_double*)&cog->y);
    dieIfFaultOccurred(&env);	
    xmlrpc_value * strctP3 = xmlrpc_array_get_item(&env, resultP, 4);
    dieIfFaultOccurred(&env);    
    xmlrpc_read_double(&env, strctP3, (xmlrpc_double*)&cog->z);
    dieIfFaultOccurred(&env);		

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}

/**
 * @brief 传动带启动、停止
 * @param [in] status 状态，1-启动，0-停止 
 * @return 错误码
 */
errno_t FRRobot::ConveyorStartEnd(uint8_t status)
{
    const char * const methodName = "ConveyorStartEnd";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)status);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup(); 

    return errcode; 
}

/**
 * @brief 记录IO检测点
 * @return 错误码
 */
errno_t FRRobot::ConveyorPointIORecord()
{
    const char * const methodName = "ConveyorPointIORecord";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();       

    return errcode;      
}

/**
 * @brief 记录A点
 * @return 错误码
 */
errno_t FRRobot::ConveyorPointARecord()
{
    const char * const methodName = "ConveyorPointARecord";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();       

    return errcode;     
}

/**
 * @brief 记录参考点
 * @return 错误码
 */
errno_t FRRobot::ConveyorRefPointRecord()
{
    const char * const methodName = "ConveyorRefPointRecord";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();       

    return errcode;   
}

/**
 * @brief 记录B点
 * @return 错误码
 */
errno_t FRRobot::ConveyorPointBRecord()
{
    const char * const methodName = "ConveyorPointBRecord";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();       

    return errcode;      
}

/**
 * @brief 传送带工件IO检测
 * @param [in] max_t 最大检测时间，单位ms
 * @return 错误码
 */
errno_t FRRobot::ConveyorIODetect(int max_t)
{
    const char * const methodName = "ConveyorIODetect";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", max_t);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup(); 

    return errcode;     
}

/**
 * @brief 获取物体当前位置
 * @param [in] mode 
 * @return 错误码
 */
errno_t FRRobot::ConveyorGetTrackData(int mode)
{
    const char * const methodName = "ConveyorGetTrackData";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", mode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup(); 

    return errcode;      
}

/**
 * @brief 传动带跟踪开始
 * @param [in] status 状态，1-启动，0-停止 
 * @return 错误码
 */
errno_t FRRobot::ConveyorTrackStart(uint8_t status)
{
    const char * const methodName = "ConveyorTrackStart";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(i)", (xmlrpc_int32)status);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup(); 

    return errcode;   
}

/**
 * @brief 传动带跟踪停止
 * @return 错误码
 */
errno_t FRRobot::ConveyorTrackEnd()
{
    const char * const methodName = "ConveyorTrackEnd";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();       

    return errcode;      
}

/**
 * @brief 传动带参数配置
 * 
 * @return 错误码
 */
errno_t FRRobot::ConveyorSetParam(float param[5])
{
    const char * const methodName = "ConveyorSetParam";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP, *arrayP1;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 5; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, param[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(A)",arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;		
}

/**
 * @brief 传动带抓取点补偿
 * @param [in] cmp 补偿位置 
 * @return 错误码
 */
errno_t FRRobot::ConveyorCatchPointComp(double cmp[3])
{
    const char * const methodName = "ConveyorCatchPointComp";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
	xmlrpc_value *arrayP, *arrayP1;
    xmlrpc_int32  errcode;
	int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
	arrayP = xmlrpc_array_new(&env);
	dieIfFaultOccurred(&env);

	for(i = 0; i < 3; i++)
	{
		xmlrpc_value * dividendP = xmlrpc_double_new(&env, cmp[i]);
		dieIfFaultOccurred(&env);
		xmlrpc_array_append_item(&env, arrayP, dividendP);
		dieIfFaultOccurred(&env);
		xmlrpc_DECREF(dividendP);
	}

    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(A)",arrayP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	    
}

/**
 * @brief 直线运动
 * @param [in] status 状态，1-启动，0-停止 
 * @return 错误码
 */
errno_t FRRobot::TrackMoveL(char name[32], int tool, int wobj, float vel, float acc, float ovl, float blendR, uint8_t flag, uint8_t type)
{
    const char * const methodName = "TrackMoveL";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(siiddddii)", name, tool,wobj,(xmlrpc_double)vel, (xmlrpc_double)acc, (xmlrpc_double)ovl,(xmlrpc_double)blendR,(xmlrpc_int32)flag,(xmlrpc_int32)type);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup(); 

    return errcode;    
}

/**
 * @brief 获取SSH公钥
 * @param [out] keygen 公钥
 * @return 错误码
 */
errno_t FRRobot::GetSSHKeygen(char keygen[1024])
{
    const char * const methodName = "GetSSHKeygen";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    const char *str;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "()");
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
	int size = xmlrpc_array_size(&env, resultP);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
	
	xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_int(&env, strctP0, &errcode);
	dieIfFaultOccurred(&env);
	
	xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
	dieIfFaultOccurred(&env);    
    xmlrpc_read_string(&env, strctP1, &str);
	dieIfFaultOccurred(&env);	
	strncpy(keygen, str, strlen(str));
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;		
}

/**
 * @brief 下发SCP指令
 * @param [in] mode 0-上传（上位机->控制器），1-下载（控制器->上位机）
 * @param [in] sshname 上位机用户名
 * @param [in] sship 上位机ip地址
 * @param [in] usr_file_url 上位机文件路径
 * @param [in] robot_file_url 机器人控制器文件路径
 * @return 错误码
 */
errno_t FRRobot::SetSSHScpCmd(int mode, char sshname[32], char sship[32], char usr_file_url[128], char robot_file_url[128])
{
    const char * const methodName = "SetSSHScpCmd";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(issss)", mode, sshname, sship, usr_file_url, robot_file_url);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_read_int(&env, resultP, &errcode);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();
    
    return errcode;	   
}

/**
 * @brief 计算指定路径下文件的MD5值
 * @param [in] file_path 文件路径包含文件名，默认Traj文件夹路径为:"/fruser/traj/",如"/fruser/traj/trajHelix_aima_1.txt"
 * @param [out] md5 文件MD5值
 * @return 错误码
 */
errno_t FRRobot::ComputeFileMD5(char file_path[256], char md5[256])
{
    const char * const methodName = "ComputeFileMD5";
    
    xmlrpc_env env;
    xmlrpc_value *resultP;
    xmlrpc_int32  errcode;
    int i;
    const char *str;
    
    xmlrpc_env_init(&env);
    xmlrpc_client_init2(&env, XMLRPC_CLIENT_NO_FLAGS, NAME, VERSION, NULL, 0);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    resultP = xmlrpc_client_call(&env, serverUrl, methodName, "(s)", file_path);
	errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();        
        return errcode;        
    }
    
    int size = xmlrpc_array_size(&env, resultP);
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }    

    xmlrpc_value * strctP0 = xmlrpc_array_get_item(&env, resultP, 0);
    errcode = dieIfFaultOccurred(&env);   

    xmlrpc_read_int(&env, strctP0, &errcode);
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }    	
    xmlrpc_value * strctP1 = xmlrpc_array_get_item(&env, resultP, 1);
    errcode = dieIfFaultOccurred(&env);    
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }        
    xmlrpc_read_string(&env, strctP1, &str);
    errcode = dieIfFaultOccurred(&env);
    if(errcode)
    {
        xmlrpc_DECREF(resultP);
        xmlrpc_env_clean(&env);
        xmlrpc_client_cleanup();   
        return errcode;          
    }        
    strncpy(md5, str, strlen(str));	

    xmlrpc_DECREF(resultP);
    xmlrpc_env_clean(&env);
    xmlrpc_client_cleanup();

    return errcode;	     
}

/**
 * @brief 获取机器人急停状态
 * @param [out] state 急停状态，0-非急停，1-急停
 * @return 错误码  
 */
errno_t FRRobot::GetRobotEmergencyStopState(uint8_t *state)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *state = robot_state_pkg.EmergencyStop;
        //printf("emergency = %u\n", robot_state_pkg.EmergencyStop);
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	   

}

/**
 * @brief 获取SDK与机器人的通讯状态
 * @param [out]  state 通讯状态，0-通讯正常，1-通讯异常
 */
errno_t FRRobot::GetSDKComState(int *state)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *state = 0;
    }
    else if(g_sock_com_err == ERR_SOCKET_COM_FAILED)
    {
        *state = 1;
    }

    int tmp_state = *state;

    //printf("com state = %d\n", tmp_state);

    return errcode;	     
}

/**
 * @brief 获取安全停止信号
 * @param [out]  si0_state 安全停止信号SI0
 * @param [out]  si1_state 安全停止信号SI1
 */
errno_t FRRobot::GetSafetyStopState(uint8_t *si0_state, uint8_t *si1_state)
{
    int errcode = 0;

    if(g_sock_com_err == ERR_SUCCESS)
    {
        *si0_state = robot_state_pkg.safety_stop0_state;
        *si1_state = robot_state_pkg.safety_stop1_state;
        //printf("emergency = %u\n", robot_state_pkg.EmergencyStop);
    }
    else
    {
        errcode = g_sock_com_err;
    }

    return errcode;	   
}


/**
 * @brief  机器人接口类析构函数
 */ 
FRRobot::~FRRobot(void)
{


}
