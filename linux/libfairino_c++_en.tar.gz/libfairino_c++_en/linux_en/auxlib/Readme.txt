1.If auxlib (libz, libcurl, libssl, libcrypto) already exists in the Linux environment, there is no need to add it;
